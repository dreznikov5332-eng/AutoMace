package com.automace;

import com.automace.combo.ComboController;
import com.automace.combo.MaceController;
import com.automace.combo.SpearController;
import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import com.automace.inventory.InventoryManager;
import com.automace.swap.AttributeSwapController;
import com.automace.swap.LungeLoopController;
import com.automace.target.TargetManager;
import com.automace.tracker.PlayerStateTracker;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Entry point: creates the modules, registers the keys and drives everything from one client tick. */
public final class AutoMaceClient implements ClientModInitializer {
    public static final String MOD_ID = "automace";

    private AutoMaceConfig config;
    private Diagnostics diag;
    private PlayerStateTracker tracker;
    private TargetManager targets;
    private InventoryManager inventory;
    private AttributeSwapController attributeSwap;
    private ComboController combo;
    private LungeLoopController lungeLoop;

    private KeyBinding startKey;
    private KeyBinding stopKey;
    private KeyBinding lungeKey;
    private long tick;

    @Override
    public void onInitializeClient() {
        config = AutoMaceConfig.load();
        diag = new Diagnostics(config);
        tracker = new PlayerStateTracker(config, diag);
        targets = new TargetManager(config, diag);
        inventory = new InventoryManager(config, diag);
        attributeSwap = new AttributeSwapController(config, diag, inventory, tracker);
        combo = new ComboController(config, diag, targets, tracker, inventory,
                attributeSwap, new SpearController(), new MaceController());

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        startKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.automace.start", GLFW.GLFW_KEY_R, category));
        stopKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.automace.stop", GLFW.GLFW_KEY_X, category));

        lungeKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.automace.lunge", GLFW.GLFW_KEY_V, category));
        lungeLoop = new LungeLoopController(config, diag, attributeSwap, lungeKey);

        ClientTickEvents.START_CLIENT_TICK.register(this::onStartTick);
        ClientTickEvents.END_CLIENT_TICK.register(this::onEndTick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            combo.emergencyStop("disconnected");
            lungeLoop.emergencyStop("disconnected");
            attributeSwap.cancel("disconnected");
            tracker.reset();
        });
        diag.log("init", "AutoMace scaffold loaded, variant=" + config.variant);
    }

    /**
     * Start of the tick, BEFORE vanilla input handling: a pending swap selects the effect item and registers
     * the attack-key press, so the click is processed with the effect item in hand.
     */
    private void onStartTick(MinecraftClient mc) {
        tick++;
        diag.setTick(tick);
        if (mc.player == null || mc.world == null) {
            return;
        }
        attributeSwap.startTick(mc);
    }

    /** End of the tick, AFTER vanilla input handling. */
    private void onEndTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            tracker.reset();
            return;
        }

        // the stop key is processed first and always wins
        while (stopKey.wasPressed()) {
            combo.emergencyStop("user pressed the stop key");
            lungeLoop.emergencyStop("user pressed the stop key");
            attributeSwap.cancel("user pressed the stop key");
        }

        // restore the carrier BEFORE the tracker reads the slot, so that the tracker sees the carrier as "held"
        attributeSwap.endTick(mc);
        tracker.update(mc.player, tick);

        while (startKey.wasPressed()) {
            combo.requestStart(mc);
        }
        combo.tick(mc);
        lungeLoop.endTick(mc);
    }
}
