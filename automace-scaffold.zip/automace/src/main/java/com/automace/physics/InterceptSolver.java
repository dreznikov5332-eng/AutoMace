package com.automace.physics;

import net.minecraft.util.math.Vec3d;

import java.util.Optional;

/**
 * Plans the wind charge throw: WHEN to throw it (delay) and WHERE to aim, so that the charge hits the flying
 * ender pearl as far / as high as possible.
 *
 * A charge flies in a straight line at a fixed speed, a pearl flies along an arc. A charge thrown now and aimed
 * at the pearl's future position P(k) generally misses it, because it arrives at a different time. The charge only
 * meets the pearl at special points, and which points are reachable depends on WHEN the charge is thrown.
 * So the solver tries every delay from 0 to maxDelayTicks: for each delay it aims the charge at the pearl's position
 * at different future times and checks, by continuous collision between the two moving hitboxes, whether they meet.
 * From all hits it picks the best one by score = heightWeight * height gain + distanceWeight * horizontal distance
 * (default: height only, so the charge hits the pearl high in its flight, near the apex, not just before it lands),
 * subject to a minimum impact height (no teleport into the ground). Among almost equal scores the earlier throw wins.
 * The planner is re-run every tick with fresh observations, the charge is thrown when the best delay is 0.
 *
 * The player's own movement is part of the model: while the planner waits, the player keeps moving (running), so the
 * charge is thrown from a different spot, and the charge inherits the player's momentum at the moment of the throw.
 * The movement is predicted as constant horizontal speed; vertical speed follows gravity while the player is airborne.
 *
 * All motion constants come from Params (config) and are DEFAULTS TO BE CHECKED against the in-game log.
 * Terrain and random projectile spread are ignored.
 * One tick: position += velocity; velocity *= drag; velocity.y -= gravity.
 */
public final class InterceptSolver {

    public record Params(double pearlDrag, double pearlGravity,
                         double chargeSpeed, double chargeGravity, boolean chargeInheritsMomentum,
                         double hitRadius, int latencyTicks, int maxDelayTicks, int maxFlightTicks,
                         double minImpactY, double minScore, double heightWeight, double distanceWeight,
                         double playerGravity, double playerVerticalDrag,
                         double minPearlSpeedAtHit, double missPenalty, int minDelayTicks) {
    }

    public record Solution(Vec3d aimDirection, int delayTicks, int flightTicks, Vec3d impactPoint,
                           double missDistance, double score, double heightGain, int latencyTicks) {
    }

    /** Scores closer than this (blocks) are treated as equal and the earlier throw is preferred. */
    private static final double SCORE_TIE = 0.25;

    private InterceptSolver() {
    }

    /** Pearl positions P[0..ticks] (P[0] is the given state). */
    public static Vec3d[] predictPearl(Vec3d pos, Vec3d vel, int ticks, double drag, double gravity) {
        Vec3d[] out = new Vec3d[ticks + 1];
        out[0] = pos;
        Vec3d p = pos;
        Vec3d v = vel;
        for (int i = 1; i <= ticks; i++) {
            // measured from the log: the velocity read from the entity is the one BEFORE the tick's drag/gravity,
            // the real displacement of the next tick is v * drag - gravity (not v)
            v = v.multiply(drag);
            v = new Vec3d(v.x, v.y - gravity, v.z);
            p = p.add(v);
            out[i] = p;
        }
        return out;
    }

    /**
     * @param pearlPos observed pearl position
     * @param pearlVel observed pearl velocity
     * @param eye        player eye position now
     * @param motion     player movement per tick (actual displacement of the last tick)
     * @param airborne   the player is not on the ground (vertical motion then counts for momentum and follows gravity)
     * @param origin     reference point for the score (the player's feet position)
     */
    public static Optional<Solution> solve(Vec3d pearlPos, Vec3d pearlVel, Vec3d eye, Vec3d motion,
                                           boolean airborne, Vec3d origin, Params prm) {
        int maxFlight = prm.maxFlightTicks();
        int total = prm.latencyTicks() + prm.maxDelayTicks() + maxFlight + 2;
        Vec3d[] pearl = predictPearl(pearlPos, pearlVel, total, prm.pearlDrag(), prm.pearlGravity());

        // where the player (and so the charge spawn) will be after `delay` ticks, and its momentum then
        int nd = prm.maxDelayTicks();
        Vec3d[] spawnAt = new Vec3d[nd + 1];
        Vec3d[] momentumAt = new Vec3d[nd + 1];
        Vec3d s = eye;
        double vy = motion.y;
        for (int d = 0; d <= nd; d++) {
            Vec3d step = new Vec3d(motion.x, airborne ? vy : 0.0, motion.z);
            spawnAt[d] = s;
            momentumAt[d] = prm.chargeInheritsMomentum() ? step : Vec3d.ZERO;
            s = s.add(step);
            if (airborne) {
                vy = (vy - prm.playerGravity()) * prm.playerVerticalDrag();
            }
        }

        Solution best = null;
        for (int delay = Math.max(0, prm.minDelayTicks()); delay <= nd; delay++) {
            Vec3d spawn = spawnAt[delay];
            Vec3d m = momentumAt[delay];
            int t0 = prm.latencyTicks() + delay; // pearl index at the moment the charge exists on the server
            for (int k = 1; k <= maxFlight; k++) {
                // Aim so that the charge's straight line (aim * speed + momentum) points at the pearl's position after k ticks:
                // the momentum is subtracted, otherwise a running player would drift off the target.
                Vec3d w = pearl[t0 + k].subtract(spawn).multiply(1.0 / k).subtract(m);
                if (w.lengthSquared() < 1.0e-6) {
                    continue;
                }
                Vec3d dir = w.normalize();
                Vec3d cv = dir.multiply(prm.chargeSpeed()).add(m);

                Vec3d prevC = spawn;
                double bestMiss = Double.MAX_VALUE;
                Vec3d bestImpact = null;
                int bestJ = 0;
                for (int j = 0; j < maxFlight; j++) {
                    Vec3d nextC = prevC.add(cv);
                    Vec3d pa = pearl[t0 + j];
                    Vec3d pb = pearl[t0 + j + 1];
                    // relative position over this tick is linear in tau in [0, 1]
                    Vec3d r0 = prevC.subtract(pa);
                    Vec3d r1 = nextC.subtract(pb);
                    Vec3d d = r1.subtract(r0);
                    double dd = d.lengthSquared();
                    double tau = dd < 1.0e-9 ? 0.0
                            : Math.max(0.0, Math.min(1.0, -(r0.x * d.x + r0.y * d.y + r0.z * d.z) / dd));
                    double dist = r0.add(d.multiply(tau)).length();
                    if (dist < bestMiss) {
                        bestMiss = dist;
                        bestImpact = pa.add(pb.subtract(pa).multiply(tau));
                        bestJ = j;
                    }
                    prevC = nextC;
                    cv = new Vec3d(cv.x, cv.y - prm.chargeGravity(), cv.z);
                }
                if (bestImpact == null || bestMiss > prm.hitRadius()) {
                    continue;
                }
                if (bestImpact.y < prm.minImpactY()) {
                    continue;
                }
                // measured: the pearl was activated only while it was still flying fast (young, rising); the slow part
                // near the apex / the descent produced no activation even with a central pass
                if (pearl[t0 + bestJ + 1].subtract(pearl[t0 + bestJ]).length() < prm.minPearlSpeedAtHit()) {
                    continue;
                }
                double gain = bestImpact.y - origin.y;
                double dx = bestImpact.x - origin.x;
                double dz = bestImpact.z - origin.z;
                double score = prm.heightWeight() * gain + prm.distanceWeight() * Math.sqrt(dx * dx + dz * dz)
                        - prm.missPenalty() * bestMiss;
                if (score < prm.minScore()) {
                    continue;
                }
                boolean better = best == null || score > best.score() + SCORE_TIE
                        || (Math.abs(score - best.score()) <= SCORE_TIE && delay < best.delayTicks());
                if (better) {
                    best = new Solution(dir, delay, bestJ + 1, bestImpact, bestMiss, score, gain, prm.latencyTicks());
                }
            }
        }
        return Optional.ofNullable(best);
    }
}
