package com.automace.physics;

import net.minecraft.util.math.Vec3d;

import java.util.Optional;

/**
 * Computes where to throw a wind charge so that it hits a flying ender pearl.
 *
 * All motion constants come from the config / Params and are DEFAULTS TO BE CHECKED against the in-game log
 * (the cycle logs predicted vs actual positions). Terrain and random projectile spread are ignored.
 *
 * Model (one tick): position += velocity; velocity *= drag; velocity.y -= gravity.
 * The pearl is observed with a delay and the charge appears on the server with a delay, so the pearl state is
 * advanced by latencyTicks before the charge flight starts.
 */
public final class InterceptSolver {

    public record Params(double pearlDrag, double pearlGravity,
                         double chargeSpeed, double chargeGravity, boolean chargeInheritsMomentum,
                         double hitRadius, int latencyTicks, int maxTicks, double minHeightGain) {
    }

    public record Solution(Vec3d aimDirection, int flightTicks, Vec3d impactPoint,
                           double missDistance, double heightGain, int latencyTicks) {
    }

    private InterceptSolver() {
    }

    /** Pearl positions P[0..n] (P[0] is the given state). */
    public static Vec3d[] predictPearl(Vec3d pos, Vec3d vel, int ticks, double drag, double gravity) {
        Vec3d[] out = new Vec3d[ticks + 1];
        out[0] = pos;
        Vec3d p = pos;
        Vec3d v = vel;
        for (int i = 1; i <= ticks; i++) {
            p = p.add(v);
            v = v.multiply(drag);
            v = new Vec3d(v.x, v.y - gravity, v.z);
            out[i] = p;
        }
        return out;
    }

    /**
     * @param pearlPos    observed pearl position
     * @param pearlVel    observed pearl velocity
     * @param spawn       where the charge starts (player eye)
     * @param momentum    player velocity (added to the charge velocity if chargeInheritsMomentum)
     * @param playerY     player Y, for the height gain
     */
    public static Optional<Solution> solve(Vec3d pearlPos, Vec3d pearlVel, Vec3d spawn, Vec3d momentum,
                                           double playerY, Params prm) {
        // pearl at the moment the charge starts to exist on the server
        Vec3d[] adv = predictPearl(pearlPos, pearlVel, prm.latencyTicks(), prm.pearlDrag(), prm.pearlGravity());
        Vec3d startPos = adv[prm.latencyTicks()];
        Vec3d startVel = pearlVel;
        for (int i = 0; i < prm.latencyTicks(); i++) {
            startVel = startVel.multiply(prm.pearlDrag());
            startVel = new Vec3d(startVel.x, startVel.y - prm.pearlGravity(), startVel.z);
        }
        int n = prm.maxTicks();
        Vec3d[] pearl = predictPearl(startPos, startVel, n + 1, prm.pearlDrag(), prm.pearlGravity());
        Vec3d m = prm.chargeInheritsMomentum() ? momentum : Vec3d.ZERO;

        Solution best = null;
        for (int k = 1; k <= n; k++) {
            Vec3d target = pearl[k];
            Vec3d dir = target.subtract(spawn);
            if (dir.lengthSquared() < 1.0e-6) {
                continue;
            }
            dir = dir.normalize();
            Vec3d chargeVel = dir.multiply(prm.chargeSpeed()).add(m);

            // charge positions C[0..n+1]
            Vec3d cv = chargeVel;
            Vec3d prevC = spawn;
            double bestMiss = Double.MAX_VALUE;
            Vec3d bestImpact = null;
            for (int j = 0; j < n; j++) {
                Vec3d nextC = prevC.add(cv);
                Vec3d nextCv = new Vec3d(cv.x, cv.y - prm.chargeGravity(), cv.z);
                // relative position over this tick, linear in tau in [0, 1]
                Vec3d r0 = prevC.subtract(pearl[j]);
                Vec3d r1 = nextC.subtract(pearl[j + 1]);
                Vec3d d = r1.subtract(r0);
                double dd = d.lengthSquared();
                double tau = dd < 1.0e-9 ? 0.0 : Math.max(0.0, Math.min(1.0, -(r0.x * d.x + r0.y * d.y + r0.z * d.z) / dd));
                Vec3d r = r0.add(d.multiply(tau));
                double dist = r.length();
                if (dist < bestMiss) {
                    bestMiss = dist;
                    Vec3d pa = pearl[j];
                    Vec3d pb = pearl[j + 1];
                    bestImpact = pa.add(pb.subtract(pa).multiply(tau));
                }
                prevC = nextC;
                cv = nextCv;
            }
            if (bestImpact == null || bestMiss > prm.hitRadius()) {
                continue;
            }
            double gain = bestImpact.y - playerY;
            if (gain < prm.minHeightGain()) {
                continue;
            }
            if (best == null || bestImpact.y > best.impactPoint().y) {
                best = new Solution(dir, k, bestImpact, bestMiss, gain, prm.latencyTicks());
            }
        }
        return Optional.ofNullable(best);
    }
}
