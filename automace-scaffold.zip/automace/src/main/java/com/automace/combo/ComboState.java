package com.automace.combo;

/** State order from the spec (section 9). */
public enum ComboState {
    IDLE,
    TARGET_ACQUISITION,
    PREPARATION,
    PEARL_THROW,
    TELEPORT_CONFIRMATION,
    WIND_CHARGE,
    ASCENT_TRACKING,
    SPEAR_SETUP,
    SPEAR_ACTION,
    MACE_TRANSITION,
    MACE_ATTACK,
    RESULT_VERIFICATION,
    RECOVERY
}
