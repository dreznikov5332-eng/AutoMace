package com.automace.combo;

/**
 * Contract for the combo phase modules. A module that has no confirmed mechanics reports
 * isDefined() == false, and the state machine stops with that reason instead of guessing.
 */
public interface PhaseController {
    boolean isDefined();

    /** Why the module is not defined yet (shown in diagnostics). */
    String undefinedReason();
}
