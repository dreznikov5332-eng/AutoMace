package com.automace.combo;

import com.automace.inventory.ItemRole;
import com.automace.swap.AttributeSwapController.SwapAction;
import com.automace.swap.AttributeSwapController.SwapPlan;
import net.minecraft.entity.LivingEntity;

import java.util.Optional;

/**
 * Mace smash through Attribute Swap: the spear is in hand (carrier, its attributes are used), the swap switches to
 * the mace and attacks the target in the same tick. ASSUMPTION (not verified): spear as the carrier.
 */
public final class MaceController implements PhaseController {
    public static final SwapPlan SMASH = new SwapPlan("mace-smash", ItemRole.SPEAR, ItemRole.MACE,
            SwapAction.ATTACK_ENTITY, false);

    @Override
    public boolean isDefined() {
        return true;
    }

    @Override
    public String undefinedReason() {
        return "";
    }

    public Optional<SwapPlan> planSmash(LivingEntity target) {
        return Optional.of(SMASH);
    }
}
