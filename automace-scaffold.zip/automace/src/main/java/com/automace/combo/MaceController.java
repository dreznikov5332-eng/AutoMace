package com.automace.combo;

import com.automace.swap.AttributeSwapController.SwapPlan;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Optional;

/**
 * Mace smash. Skeleton only: when and how to switch to the mace (which attributes carry over,
 * at which moment of the fall) depends on the confirmed technique.
 *
 * Contract: the transition to the mace goes through AttributeSwapController (SwapPlan), never through a
 * plain slot switch, to avoid the delay between the spear action and the mace attack.
 */
public final class MaceController implements PhaseController {

    @Override
    public boolean isDefined() {
        return false;
    }

    @Override
    public String undefinedReason() {
        return "mace transition and smash moment (carrier/effect pair, timing relative to the spear action) are not confirmed";
    }

    /** Swap plan for the transition to the mace. Empty until confirmed. */
    public Optional<SwapPlan> planSmash(PlayerEntity target) {
        return Optional.empty();
    }
}
