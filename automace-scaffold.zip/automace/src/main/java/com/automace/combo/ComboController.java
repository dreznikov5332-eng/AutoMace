package com.automace.combo;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import com.automace.inventory.InventoryManager;
import com.automace.swap.AttributeSwapController;
import com.automace.swap.AttributeSwapController.SwapPlan;
import com.automace.swap.AttributeSwapController.SwapResult;
import com.automace.target.TargetManager;
import com.automace.tracker.PlayerStateTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;

import java.util.List;
import java.util.Optional;

/**
 * Finite state machine for the whole combo.
 *
 * Implemented in this stage: IDLE, TARGET_ACQUISITION, PREPARATION, RECOVERY and the generic guards
 * (timeout, cancel, death, world change, attempt rate limit).
 * PEARL_THROW ... SPEAR_ACTION (stage 3/4) are not implemented: the mechanics are not verified, so the
 * machine ends with an explicit reason instead of guessing.
 * MACE_TRANSITION is wired to AttributeSwapController but stays unreachable until the earlier phases exist.
 */
public final class ComboController implements AttributeSwapController.Listener {

    private final AutoMaceConfig config;
    private final Diagnostics diag;
    private final TargetManager targets;
    private final PlayerStateTracker tracker;
    private final InventoryManager inventory;
    private final AttributeSwapController attributeSwap;
    private final SpearController spear;
    private final MaceController mace;

    private ComboState state = ComboState.IDLE;
    private long stateEnterTick;
    private long lastAttemptEndTick = -1_000_000L;
    private String endReason = "-";
    private ClientWorld worldAtStart;

    public ComboController(AutoMaceConfig config, Diagnostics diag, TargetManager targets,
                           PlayerStateTracker tracker, InventoryManager inventory,
                           AttributeSwapController attributeSwap, SpearController spear, MaceController mace) {
        this.config = config;
        this.diag = diag;
        this.targets = targets;
        this.tracker = tracker;
        this.inventory = inventory;
        this.attributeSwap = attributeSwap;
        this.spear = spear;
        this.mace = mace;
        attributeSwap.addListener(this);
    }

    public ComboState state() {
        return state;
    }

    public String endReason() {
        return endReason;
    }

    private void enter(ComboState next, String why) {
        diag.log("combo", state + " -> " + next + " (" + why + ")");
        state = next;
        stateEnterTick = diag.tick();
    }

    // --- control ---

    public void requestStart(MinecraftClient mc) {
        if (!config.enabled) {
            diag.refusal("combo", "mod is disabled in the config");
            return;
        }
        if (state != ComboState.IDLE) {
            diag.refusal("combo", "already running (" + state + ")");
            return;
        }
        long sinceLast = diag.tick() - lastAttemptEndTick;
        if (sinceLast < config.minTicksBetweenAttempts) {
            diag.refusal("combo", "too soon after the previous attempt (" + sinceLast + " < "
                    + config.minTicksBetweenAttempts + " ticks)");
            return;
        }
        worldAtStart = mc.world;
        enter(ComboState.TARGET_ACQUISITION, "start requested");
    }

    /** Immediate stop from the user, death, disconnect or world change. Always allowed. */
    public void emergencyStop(String reason) {
        if (state == ComboState.IDLE) {
            return;
        }
        diag.log("combo", "EMERGENCY STOP: " + reason);
        endReason = "stopped: " + reason;
        attributeSwap.cancel(reason);
        finish();
    }

    private void finish() {
        targets.release();
        tracker.endManeuver();
        lastAttemptEndTick = diag.tick();
        state = ComboState.IDLE;
        stateEnterTick = diag.tick();
    }

    private void fail(String reason) {
        endReason = reason;
        diag.refusal("combo", reason);
        enter(ComboState.RECOVERY, reason);
    }

    // --- tick ---

    public void tick(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (state == ComboState.IDLE) {
            return;
        }
        if (me == null || mc.world == null) {
            emergencyStop("no player or world");
            return;
        }
        if (me.isDead() || me.getHealth() <= 0f) {
            emergencyStop("player died");
            return;
        }
        if (mc.world != worldAtStart) {
            emergencyStop("world changed");
            return;
        }
        if (state != ComboState.RECOVERY && diag.tick() - stateEnterTick > config.defaultStateTimeoutTicks) {
            fail("timeout in state " + state);
            return;
        }

        switch (state) {
            case TARGET_ACQUISITION -> {
                String err = targets.acquire(mc);
                if (err != null) {
                    fail(err);
                } else {
                    enter(ComboState.PREPARATION, "target locked");
                }
            }
            case PREPARATION -> {
                String err = targets.validateCurrent(me);
                if (err != null) {
                    fail(err);
                    return;
                }
                List<String> missing = inventory.missingForCombo(me);
                if (!missing.isEmpty()) {
                    fail("missing items: " + String.join(", ", missing));
                    return;
                }
                tracker.startManeuver();
                enter(ComboState.PEARL_THROW, "preparation passed");
            }
            case PEARL_THROW, TELEPORT_CONFIRMATION, WIND_CHARGE, ASCENT_TRACKING, SPEAR_SETUP, SPEAR_ACTION ->
                    unsupported(state, "pearl / wind charge / spear mechanics are not verified yet (stage 3-4)");
            case MACE_TRANSITION -> maceTransition();
            case MACE_ATTACK -> {
                // reached from onSwapSent(); the attack itself is sent by AttributeSwapController
                enter(ComboState.RESULT_VERIFICATION, "swap-attack sent");
            }
            case RESULT_VERIFICATION -> {
                // waiting for onSwapVerified()
            }
            case RECOVERY -> {
                diag.log("combo", "finished: " + endReason);
                finish();
            }
            default -> { }
        }

        String status = "[" + state + "] " + (targets.hasTarget()
                ? String.format("dist=%.1f ", me.distanceTo(targets.current())) : "")
                + String.format("vy=%.2f ", tracker.current() == null ? 0.0 : tracker.current().verticalSpeed())
                + "slot=" + me.getInventory().getSelectedSlot()
                + " last=" + diag.lastAction()
                + (diag.lastRefusal().equals("-") ? "" : " ! " + diag.lastRefusal());
        diag.showStatus(me, status);
    }

    private void unsupported(ComboState s, String reason) {
        fail("state " + s + " not implemented: " + reason);
    }

    private void maceTransition() {
        PlayerEntity target = targets.current();
        if (!mace.isDefined()) {
            unsupported(ComboState.MACE_TRANSITION, mace.undefinedReason());
            return;
        }
        Optional<SwapPlan> plan = mace.planSmash(target);
        if (plan.isEmpty()) {
            fail("mace module returned no swap plan");
            return;
        }
        if (!attributeSwap.isBusy() && !attributeSwap.request(plan.get(), target)) {
            fail("attribute swap request refused");
        }
        // the swap is executed by AttributeSwapController.tick() in this same tick
    }

    // --- AttributeSwapController.Listener ---

    @Override
    public void onSwapSent(SwapResult result) {
        if (state == ComboState.MACE_TRANSITION) {
            enter(ComboState.MACE_ATTACK, "swap + attack sent in the same tick");
        }
    }

    @Override
    public void onSwapVerified(SwapResult result) {
        if (state == ComboState.RESULT_VERIFICATION || state == ComboState.MACE_ATTACK) {
            endReason = "result: " + result.outcome() + " (" + result.detail() + ")";
            enter(ComboState.RECOVERY, endReason);
        }
    }

    @Override
    public void onSwapRefused(SwapPlan plan, String reason, AttributeSwapController.RefusalKind kind) {
        if (state == ComboState.MACE_TRANSITION || state == ComboState.MACE_ATTACK) {
            fail("attribute swap refused: " + reason);
        }
    }
}
