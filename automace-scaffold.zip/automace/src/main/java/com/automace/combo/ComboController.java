package com.automace.combo;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import com.automace.cycle.PearlChargeCycle;
import com.automace.inventory.InventoryManager;
import com.automace.inventory.ItemRole;
import com.automace.swap.LungeLoopController;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.math.Vec3d;
import com.automace.swap.AttributeSwapController;
import com.automace.swap.AttributeSwapController.SwapPlan;
import com.automace.swap.AttributeSwapController.SwapResult;
import com.automace.target.TargetManager;
import com.automace.tracker.PlayerStateTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;

import java.util.List;
import java.util.Optional;

/**
 * Finite state machine for the whole combo.
 *
 * Implemented in this stage: IDLE, TARGET_ACQUISITION, PREPARATION, RECOVERY and the generic guards
 * (timeout, cancel, death, world change, attempt rate limit).
 * PEARL_THROW ... SPEAR_ACTION (stage 3/4) are not implemented: the mechanics are not verified, so the
 * machine ends with an explicit reason instead of guessing.
 * MACE_TRANSITION is wired to AttributeSwapController but stays unreachable until the earlier phases exist.
 */
public final class ComboController implements AttributeSwapController.Listener {

    private final AutoMaceConfig config;
    private final Diagnostics diag;
    private final TargetManager targets;
    private final PlayerStateTracker tracker;
    private final InventoryManager inventory;
    private final AttributeSwapController attributeSwap;
    private final SpearController spear;
    private final MaceController mace;
    private final PearlChargeCycle cycle;
    private final LungeLoopController lungeLoop;

    private ComboState state = ComboState.IDLE;
    private boolean loopActive;
    private boolean lastWasSmash;
    private double burstStartY;
    private double burstMaxY;
    private boolean burstRose;
    private long stateEnterTick;
    private long lastAttemptEndTick = -1_000_000L;
    private String endReason = "-";
    private ClientWorld worldAtStart;
    private double lastDist = -1;
    private int cycles;
    private int cycleFailures;
    private int reascents;
    private boolean savedRequireCharge;
    private boolean chargeOverride;

    public ComboController(AutoMaceConfig config, Diagnostics diag, TargetManager targets,
                           PlayerStateTracker tracker, InventoryManager inventory,
                           AttributeSwapController attributeSwap, SpearController spear, MaceController mace,
                           PearlChargeCycle cycle, LungeLoopController lungeLoop) {
        this.config = config;
        this.diag = diag;
        this.targets = targets;
        this.tracker = tracker;
        this.inventory = inventory;
        this.attributeSwap = attributeSwap;
        this.spear = spear;
        this.mace = mace;
        this.cycle = cycle;
        this.lungeLoop = lungeLoop;
        attributeSwap.addListener(this);
    }

    public ComboState state() {
        return state;
    }

    /** True while a combo (or the repeating loop) is active. */
    public boolean isActive() {
        return state != ComboState.IDLE;
    }

    /** Predicted launch height of the smash for the configured Wind Burst level (0 = no enchantment). */
    public double burstHeight() {
        return switch (config.maceWindBurstLevel) {
            case 1 -> config.windBurstHeightLevel1;
            case 2 -> config.windBurstHeightLevel2;
            case 3 -> config.windBurstHeightLevel3;
            default -> 0.0;
        };
    }

    public String endReason() {
        return endReason;
    }

    private void enter(ComboState next, String why) {
        lastDist = -1;
        diag.log("combo", state + " -> " + next + " (" + why + ")");
        state = next;
        stateEnterTick = diag.tick();
    }

    // --- control ---

    public void requestStart(MinecraftClient mc) {
        if (!config.enabled) {
            diag.refusal("combo", "mod is disabled in the config");
            return;
        }
        if (state != ComboState.IDLE) {
            diag.refusal("combo", "already running (" + state + ")");
            return;
        }
        long sinceLast = diag.tick() - lastAttemptEndTick;
        if (sinceLast < config.minTicksBetweenAttempts) {
            diag.refusal("combo", "too soon after the previous attempt (" + sinceLast + " < "
                    + config.minTicksBetweenAttempts + " ticks)");
            return;
        }
        worldAtStart = mc.world;
        loopActive = config.comboLoop;
        lastWasSmash = false;
        cycles = 0;
        cycleFailures = 0;
        reascents = 0;
        enter(ComboState.TARGET_ACQUISITION, "start requested");
    }

    /** Immediate stop from the user, death, disconnect or world change. Always allowed. */
    public void emergencyStop(String reason) {
        if (state == ComboState.IDLE) {
            return;
        }
        diag.log("combo", "EMERGENCY STOP: " + reason);
        loopActive = false;
        endReason = "stopped: " + reason;
        attributeSwap.cancel(reason);
        cycle.cancel(reason);
        lungeLoop.setForced(false);
        finish();
    }

    private void finish() {
        lungeLoop.setForced(false);
        restoreChargeRule();
        targets.release();
        tracker.endManeuver();
        lastAttemptEndTick = diag.tick();
        state = ComboState.IDLE;
        stateEnterTick = diag.tick();
    }

    /** Same clean-up as finish(), but the loop goes on. */
    private void endIteration() {
        lungeLoop.setForced(false);
        restoreChargeRule();
        targets.release();
        tracker.endManeuver();
        lastAttemptEndTick = diag.tick();
    }

    private void startNextIteration(ClientPlayerEntity me) {
        cycles = 0;
        cycleFailures = 0;
        reascents = 0;
        lastWasSmash = false;
        enter(ComboState.TARGET_ACQUISITION, "next loop iteration");
    }

    private void fail(String reason) {
        endReason = reason;
        diag.refusal("combo", reason);
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) {
            p.sendMessage(net.minecraft.text.Text.literal("[AutoMace] Остановлено: " + reason), false);
        }
        enter(ComboState.RECOVERY, reason);
    }

    // --- tick ---

    public void tick(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (state == ComboState.IDLE) {
            return;
        }
        if (me == null || mc.world == null) {
            emergencyStop("no player or world");
            return;
        }
        if (me.isDead() || me.getHealth() <= 0f) {
            emergencyStop("player died");
            return;
        }
        if (mc.world != worldAtStart) {
            emergencyStop("world changed");
            return;
        }
        if (state != ComboState.RECOVERY && diag.tick() - stateEnterTick > config.defaultStateTimeoutTicks) {
            fail("timeout in state " + state);
            return;
        }

        switch (state) {
            case TARGET_ACQUISITION -> {
                String err = targets.acquire(mc);
                if (err != null) {
                    fail(err);
                } else {
                    enter(ComboState.PREPARATION, "target locked");
                }
            }
            case PREPARATION -> {
                String err = targets.validateCurrent(me);
                if (err != null) {
                    fail(err);
                    return;
                }
                List<String> missing = inventory.missingForCombo(me);
                if (!missing.isEmpty()) {
                    loopActive = false;
                    fail("missing items: " + String.join(", ", missing));
                    return;
                }
                tracker.startManeuver();
                enter(ComboState.PEARL_THROW, "preparation passed");
            }
            case PEARL_THROW -> startAscent(mc, me);
            case TELEPORT_CONFIRMATION -> {
                if (!cycle.isRunning()) {
                    onCycleFinished(me);
                }
            }
            case ASCENT_TRACKING -> decideAfterAscent(me);
            case SPEAR_SETUP -> {
                // the lunge swap needs the wind charge (carrier) in hand; the ascent cycle leaves another slot selected
                int chargeSlot = inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE);
                if (chargeSlot < 0) {
                    fail("wind charge is not in the hotbar");
                    return;
                }
                if (me.getInventory().getSelectedSlot() != chargeSlot) {
                    me.getInventory().setSelectedSlot(chargeSlot);
                    mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(chargeSlot));
                    return;
                }
                LivingEntity tgt = targets.current();
                if (tgt != null) {
                    aimDash(me, tgt); // the first lunge must already fly toward the target
                }
                lungeLoop.setForced(true);
                enter(ComboState.SPEAR_ACTION, "dash started (wind charge in hand)");
            }
            case SPEAR_ACTION -> dash(me);
            case MACE_TRANSITION -> maceTransition(me);
            case MACE_ATTACK -> enter(ComboState.RESULT_VERIFICATION, "swap-attack sent");
            case RESULT_VERIFICATION -> {
                // waiting for onSwapVerified()
            }
            case RECOVERY -> {
                diag.log("combo", "finished: " + endReason);
                if (loopActive) {
                    endIteration();
                    if (lastWasSmash) {
                        burstStartY = me.getY();
                        burstMaxY = me.getY();
                        burstRose = false;
                        enter(ComboState.POST_HIT_WAIT, String.format(
                                "waiting for the Wind Burst launch (level %d, predicted +%.0f blocks)",
                                config.maceWindBurstLevel, burstHeight()));
                    } else {
                        enter(ComboState.LOOP_PAUSE, "repeat after a failed attempt");
                    }
                } else {
                    finish();
                }
            }
            case POST_HIT_WAIT -> {
                double vy = me.getVelocity().y;
                burstMaxY = Math.max(burstMaxY, me.getY());
                if (vy > 0.3) {
                    burstRose = true;
                }
                long waited = diag.tick() - stateEnterTick;
                boolean apex = burstRose && vy <= 0.05;
                if (apex || waited >= config.comboBurstWaitTicks || (me.isOnGround() && waited > 3)) {
                    diag.log("combo", String.format(
                            "Wind Burst result: level %d predicted +%.1f blocks, measured +%.1f blocks (peak y=%.1f, start y=%.1f, %d ticks)",
                            config.maceWindBurstLevel, burstHeight(), burstMaxY - burstStartY, burstMaxY, burstStartY, waited));
                    startNextIteration(me);
                }
            }
            case LOOP_PAUSE -> {
                if (diag.tick() - stateEnterTick >= config.comboLoopPauseTicks) {
                    startNextIteration(me);
                }
            }
            default -> { }
        }

        String status = "[" + state + "] " + (targets.hasTarget()
                ? String.format("dist=%.1f ", me.distanceTo(targets.current())) : "")
                + String.format("vy=%.2f ", tracker.current() == null ? 0.0 : tracker.current().verticalSpeed())
                + "slot=" + me.getInventory().getSelectedSlot()
                + " last=" + diag.lastAction()
                + (diag.lastRefusal().equals("-") ? "" : " ! " + diag.lastRefusal());
        diag.showStatus(me, status);
    }

    // --- helpers ---

    private double horizontalDistance(ClientPlayerEntity me, LivingEntity t) {
        double dx = t.getX() - me.getX();
        double dz = t.getZ() - me.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    private double requiredHeight(ClientPlayerEntity me, LivingEntity t) {
        return Math.max(config.comboMinHeightAboveTarget, horizontalDistance(me, t) * config.comboHeightPerBlock);
    }

    private float yawTo(ClientPlayerEntity me, Vec3d p) {
        return (float) (Math.toDegrees(Math.atan2(p.z - me.getZ(), p.x - me.getX())) - 90.0);
    }

    private Vec3d aimPoint(LivingEntity t) {
        return new Vec3d(t.getX(), t.getEyePos().y - 0.4, t.getZ());
    }

    private void aimAt(ClientPlayerEntity me, LivingEntity t) {
        Vec3d eye = me.getEyePos();
        Vec3d p = aimPoint(t);
        Vec3d d = p.subtract(eye);
        double len = d.length();
        if (len < 1e-6) {
            return;
        }
        me.setYaw(yawTo(me, p));
        me.setPitch((float) -Math.toDegrees(Math.asin(Math.max(-1.0, Math.min(1.0, d.y / len)))));
    }

    /**
     * Aim for the lunges: yaw at the target, but the pitch is limited downwards (comboDashMaxPitchDown). Log 57587244:
     * lunges started by hand (C, then V held, looking roughly level) reached 1.2-2.4 b/tick of horizontal speed, the
     * combo lunges (aimed straight at a target 25 blocks below, pitch ~ 75-85 down) only 0.1-0.8.
     */
    private void aimDash(ClientPlayerEntity me, LivingEntity t) {
        aimAt(me, t);
        float maxDown = (float) config.comboDashMaxPitchDown;
        if (me.getPitch() > maxDown) {
            me.setPitch(maxDown);
        }
    }

    private void restoreChargeRule() {
        if (chargeOverride) {
            config.swapRequireFullAttackCharge = savedRequireCharge;
            chargeOverride = false;
        }
    }

    // --- ascent ---

    private void startAscent(MinecraftClient mc, ClientPlayerEntity me) {
        LivingEntity t = targets.current();
        double need = requiredHeight(me, t);
        double have = me.getY() - t.getY();
        double horiz = horizontalDistance(me, t);
        // an earlier pearl that is still flying would teleport us at a random moment and break the next cycle
        if (diag.tick() - stateEnterTick < 200 && ownPearlInFlight(mc, me)) {
            return;
        }
        // how far the lunges can carry us while we fall from here (measured lunge speed, with a safety factor)
        double capacity = fallTicks(Math.max(0.0, have - 3.0), me.getVelocity().y) * config.comboLungeSpeedPerTick;
        if (have >= need && (horiz <= config.comboMaxDashHorizontal || horiz <= capacity * 0.8)) {
            enter(ComboState.SPEAR_SETUP, String.format("height is enough (%.1f >= %.1f), horizontal distance %.1f (lunges can cover ~%.1f)",
                    have, need, horiz, capacity));
            return;
        }
        boolean canTryDash = !me.isOnGround() && have >= config.comboMinHeightDuringDash + 3.0 && horiz <= capacity * 1.2;
        if (cycles >= config.ascentCyclesMax) {
            if (canTryDash) {
                enter(ComboState.SPEAR_SETUP, String.format("no pearls left for this run, trying the dash from %.1f above the target (distance %.1f, lunges ~%.1f)",
                        have, horiz, capacity));
                return;
            }
            fail("max ascent cycles reached (" + cycles + "), height above the target " + String.format("%.1f", have)
                    + " of " + String.format("%.1f", need));
            return;
        }
        cycles++;
        diag.log("combo", String.format("ascent cycle %d: height above target %.1f, need %.1f, distance %.1f",
                cycles, have, need, horizontalDistance(me, t)));
        float yaw = yawTo(me, aimPoint(t));
        Float pitch = horiz <= 3.0 ? Float.valueOf(-90f) : cycle.suggestPitch(mc, me, yaw, horiz, Math.max(6.0, need - have));
        if (pitch == null) {
            pitch = cycle.suggestPitch(mc, me, yaw, horiz, 4.0);
        }
        if (pitch == null && canTryDash) {
            // falling too fast for the pearl to work (it inherits the fall speed): dash instead of wasting the pearl
            cycles--;
            enter(ComboState.SPEAR_SETUP, "no workable pearl throw while falling, dashing from " + String.format("%.1f", have) + " above the target");
            return;
        }
        cycle.setReplan(horiz <= 3.0 ? -1 : horiz, Math.max(6.0, need - have));
        cycle.startForCombo(mc, yaw, pitch == null ? config.comboPearlPitch : pitch);
        if (!cycle.isRunning()) {
            if (canTryDash) {
                cycles--;
                enter(ComboState.SPEAR_SETUP, "pearl not thrown (" + cycle.lastEnd() + "), dashing from " + String.format("%.1f", have) + " above the target");
                return;
            }
            fail("ascent cycle did not start (" + cycle.lastEnd() + ")");
            return;
        }
        enter(ComboState.TELEPORT_CONFIRMATION, "cycle started");
    }

    private boolean ownPearlInFlight(MinecraftClient mc, ClientPlayerEntity me) {
        for (net.minecraft.entity.Entity e : mc.world.getEntities()) {
            if (e instanceof net.minecraft.entity.projectile.thrown.EnderPearlEntity pe && pe.getOwner() == me) {
                return true;
            }
        }
        return false;
    }

    private void onCycleFinished(ClientPlayerEntity me) {
        if (cycle.lastTeleported()) {
            cycleFailures = 0;
            diag.log("combo", String.format("cycle %d ok: height gain %.2f", cycles, cycle.lastHeightGain()));
        } else {
            cycleFailures++;
            diag.log("combo", "cycle " + cycles + " failed: " + cycle.lastEnd());
            if (cycleFailures > config.comboMaxCycleFailures) {
                fail("ascent cycle failed " + cycleFailures + " times in a row, last: " + cycle.lastEnd());
                return;
            }
        }
        enter(ComboState.ASCENT_TRACKING, "cycle finished");
    }

    private void decideAfterAscent(ClientPlayerEntity me) {
        String err = targets.validateCurrent(me);
        if (err != null) {
            fail(err);
            return;
        }
        // wait until the pearl cooldown / momentum allow the next cycle, the target is re-measured each time
        enter(ComboState.PEARL_THROW, "re-checking height against the target's current position");
    }

    // --- dash with the spear ---

    private void traceDash(ClientPlayerEntity me, LivingEntity t) {
        diag.log("combo", String.format("%s dist=%.2f above=%.2f vy=%.3f ground=%b slot=%d target=(%.2f, %.2f, %.2f) me=(%.2f, %.2f, %.2f)",
                state, me.distanceTo(t), me.getY() - t.getY(), me.getVelocity().y, me.isOnGround(),
                me.getInventory().getSelectedSlot(), t.getX(), t.getY(), t.getZ(), me.getX(), me.getY(), me.getZ()));
    }

    private void dash(ClientPlayerEntity me) {
        LivingEntity t = targets.current();
        if (t != null) {
            traceDash(me, t);
        }
        String err = targets.validateCurrent(me);
        if (err != null) {
            lungeLoop.setForced(false);
            fail(err);
            return;
        }
        double dist = me.distanceTo(t);
        double above = me.getY() - t.getY();
        long ticks = diag.tick() - stateEnterTick;

        double closing = lastDist < 0 ? 0.0 : Math.max(0.0, lastDist - dist);
        lastDist = dist;
        double prepDist = Math.max(config.comboLungeStopDistance,
                config.comboMaceDistance + closing * config.comboMaceLeadTicks + 1.0);
        if (dist <= prepDist) {
            lungeLoop.setForced(false);
            aimAt(me, t);
            savedRequireCharge = config.swapRequireFullAttackCharge;
            config.swapRequireFullAttackCharge = false;
            chargeOverride = true;
            enter(ComboState.MACE_TRANSITION, String.format("close enough (%.1f, closing %.2f/tick), preparing the mace", dist, closing));
            return;
        }
        // not enough fall time left to cover the horizontal distance with lunges: gain height / distance again NOW
        double horiz = horizontalDistance(me, t);
        double fallTicks = fallTicks(above, me.getVelocity().y);
        if (above >= config.comboReascentMinHeight && horiz > fallTicks * config.comboLungeSpeedPerTick + config.comboMaceDistance) {
            lungeLoop.setForced(false);
            reascendOrFail(String.format("cannot cover %.1f blocks horizontally in %.0f ticks of fall (lunge ~%.2f/tick)",
                    horiz, fallTicks, config.comboLungeSpeedPerTick));
            return;
        }
        if (ticks > config.comboDashTimeoutTicks) {
            lungeLoop.setForced(false);
            fail("dash timeout, distance " + String.format("%.1f", dist));
            return;
        }
        if (me.isOnGround() && ticks > 3) {
            lungeLoop.setForced(false);
            reascendOrFail("landed before reaching the target, distance " + String.format("%.1f", dist));
            return;
        }
        if (above < config.comboMinHeightDuringDash) {
            lungeLoop.setForced(false);
            reascendOrFail(String.format("too low during the dash (%.1f above the target, distance %.1f)", above, dist));
            return;
        }
        aimDash(me, t);
    }

    /** Ticks until the player has fallen `height` blocks (vanilla gravity model). */
    private double fallTicks(double height, double vy) {
        double y = 0;
        double v = Math.min(vy, 0.0);
        for (int i = 1; i <= 200; i++) {
            v = (v - config.playerGravity) * config.playerVerticalDrag;
            y += v;
            if (-y >= height) {
                return i;
            }
        }
        return 200;
    }

    private void reascendOrFail(String why) {
        if (reascents >= config.comboMaxReascents) {
            fail(why + "; no re-ascents left");
            return;
        }
        reascents++;
        cycleFailures = 0;
        diag.log("combo", "re-ascent " + reascents + ": " + why);
        enter(ComboState.PEARL_THROW, "re-ascent");
    }

    // --- mace ---

    private void maceTransition(ClientPlayerEntity me) {
        LivingEntity target = targets.current();
        String err = targets.validateCurrent(me);
        if (err != null) {
            fail(err);
            return;
        }
        if (diag.tick() - stateEnterTick > config.comboMaceTimeoutTicks) {
            fail("mace swap timeout");
            return;
        }
        traceDash(me, target);
        if (me.isOnGround() && diag.tick() - stateEnterTick > 1) {
            fail(String.format("landed before the strike (distance %.1f), a smash from the ground would do almost no damage",
                    me.distanceTo(target)));
            return;
        }
        aimAt(me, target);
        if (attributeSwap.isBusy()) {
            return;
        }
        int spearSlot = inventory.findHotbarSlot(me, ItemRole.SPEAR);
        if (spearSlot < 0) {
            fail("spear is not in the hotbar");
            return;
        }
        if (me.getInventory().getSelectedSlot() != spearSlot) {
            // the spear must be held for at least one tick before the swap (it is the carrier)
            me.getInventory().setSelectedSlot(spearSlot);
            net.minecraft.client.MinecraftClient.getInstance().getNetworkHandler()
                    .sendPacket(new UpdateSelectedSlotC2SPacket(spearSlot));
            return;
        }
        double d = me.distanceTo(target);
        double closing = lastDist < 0 ? 0.0 : Math.max(0.0, lastDist - d);
        lastDist = d;
        // the swap runs at the start of the next tick, so the distance is checked one tick ahead
        if (d - closing * 1.2 > config.comboMaceDistance) {
            return; // spear in hand, aiming, waiting until the enemy is (about to be) within the strike zone
        }
        Optional<SwapPlan> plan = mace.planSmash(target);
        if (plan.isEmpty()) {
            fail("mace module returned no swap plan");
            return;
        }
        attributeSwap.request(plan.get(), target);
    }

    // --- AttributeSwapController.Listener ---

    @Override
    public void onSwapSent(SwapResult result) {
        if (state == ComboState.MACE_TRANSITION && result.plan().label().equals("mace-smash")) {
            enter(ComboState.MACE_ATTACK, "swap + attack sent in the same tick");
        }
    }

    @Override
    public void onSwapVerified(SwapResult result) {
        if (result.plan().label().equals("mace-smash")
                && (state == ComboState.RESULT_VERIFICATION || state == ComboState.MACE_ATTACK)) {
            endReason = "result: " + result.outcome() + " (" + result.detail() + ")";
            lastWasSmash = result.outcome() == AttributeSwapController.Outcome.HIT_SIGNAL;
            enter(ComboState.RECOVERY, endReason);
        }
    }

    @Override
    public void onSwapRefused(SwapPlan plan, String reason, AttributeSwapController.RefusalKind kind) {
        if (!plan.label().equals("mace-smash")) {
            return;
        }
        if (kind == AttributeSwapController.RefusalKind.INVALID
                && (state == ComboState.MACE_TRANSITION || state == ComboState.MACE_ATTACK)) {
            fail("attribute swap refused: " + reason);
        }
    }
}
