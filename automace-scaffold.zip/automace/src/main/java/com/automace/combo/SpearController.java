package com.automace.combo;

import com.automace.inventory.ItemRole;
import com.automace.swap.AttributeSwapController.SwapAction;
import com.automace.swap.AttributeSwapController.SwapPlan;
import net.minecraft.entity.LivingEntity;

import java.util.Optional;

/** Spear dash: wind charge in hand -> (same tick) spear + LMB (Lunge) -> wind charge. Confirmed by the user. */
public final class SpearController implements PhaseController {
    public static final SwapPlan LUNGE = new SwapPlan("lunge", ItemRole.WIND_CHARGE, ItemRole.SPEAR,
            SwapAction.ATTACK_KEY, true);

    @Override
    public boolean isDefined() {
        return true;
    }

    @Override
    public String undefinedReason() {
        return "";
    }

    public Optional<SwapPlan> planSwap(LivingEntity target) {
        return Optional.of(LUNGE);
    }
}
