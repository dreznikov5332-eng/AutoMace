package com.automace.combo;

import com.automace.swap.AttributeSwapController.SwapPlan;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Optional;

/**
 * Spear actions (Jab / Charge / Lunge). Skeleton only: the order of actions, timing and direction
 * must come from a verified demonstration of the Spear Mace technique and are NOT invented here.
 *
 * Contract with AttributeSwapController: when the technique needs a swap while moving with the spear,
 * this module builds a SwapPlan (carrier / effect item) and the ComboController hands it to
 * AttributeSwapController.request(). This module never switches slots itself.
 */
public final class SpearController implements PhaseController {

    @Override
    public boolean isDefined() {
        return false;
    }

    @Override
    public String undefinedReason() {
        return "spear action sequence (jab / charge / lunge, timing, direction) is not confirmed by a demonstration";
    }

    /** Swap plan for the spear step. Empty until the technique is confirmed (the carrier / effect pair is open). */
    public Optional<SwapPlan> planSwap(PlayerEntity target) {
        return Optional.empty();
    }
}
