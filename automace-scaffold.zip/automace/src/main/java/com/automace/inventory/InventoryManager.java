package com.automace.inventory;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;

import java.util.ArrayList;
import java.util.List;

/**
 * Finds the combo items in the hotbar and checks availability.
 * Only a plain local slot selection lives here. The Attribute Swap (slot switch + attack in the
 * same tick) is NOT done here, it belongs to AttributeSwapController.
 */
public final class InventoryManager {
    public static final int HOTBAR_SIZE = 9;

    private final AutoMaceConfig config;
    private final Diagnostics diag;

    public InventoryManager(AutoMaceConfig config, Diagnostics diag) {
        this.config = config;
        this.diag = diag;
    }

    public boolean matches(ItemRole role, ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        return switch (role) {
            case ENDER_PEARL -> stack.isOf(Items.ENDER_PEARL);
            case WIND_CHARGE -> stack.isOf(Items.WIND_CHARGE);
            case MACE -> stack.isOf(Items.MACE);
            case SPEAR -> isSpear(stack);
        };
    }

    /**
     * PROVISIONAL: spears are recognised by item id suffix "_spear". The exact check
     * (components / tags) is to be confirmed together with the spear mechanics.
     */
    public boolean isSpear(ItemStack stack) {
        return Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear");
    }

    private int preferredSlot(ItemRole role) {
        return switch (role) {
            case ENDER_PEARL -> config.preferredSlotEnderPearl;
            case WIND_CHARGE -> config.preferredSlotWindCharge;
            case SPEAR -> config.preferredSlotSpear;
            case MACE -> config.preferredSlotMace;
        };
    }

    /** Hotbar slot 0..8 holding the item of this role, or -1. The preferred slot wins. */
    public int findHotbarSlot(ClientPlayerEntity player, ItemRole role) {
        PlayerInventory inv = player.getInventory();
        int preferred = preferredSlot(role);
        if (preferred >= 0 && preferred < HOTBAR_SIZE && matches(role, inv.getStack(preferred))) {
            return preferred;
        }
        for (int i = 0; i < HOTBAR_SIZE; i++) {
            if (matches(role, inv.getStack(i))) {
                return i;
            }
        }
        return -1;
    }

    /** Total count of such items across the whole inventory (for consumables). */
    public int countTotal(ClientPlayerEntity player, ItemRole role) {
        PlayerInventory inv = player.getInventory();
        int total = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (matches(role, s)) {
                total += s.getCount();
            }
        }
        return total;
    }

    /** Role of the item currently in the main hand, or null if it is none of the combo items. */
    public ItemRole roleInHand(ClientPlayerEntity player) {
        ItemStack held = player.getInventory().getSelectedStack();
        for (ItemRole r : ItemRole.values()) {
            if (matches(r, held)) {
                return r;
            }
        }
        return null;
    }

    /** What is missing for the combo (empty list means ready). Items are NOT moved. */
    public List<String> missingForCombo(ClientPlayerEntity player) {
        List<String> missing = new ArrayList<>();
        for (ItemRole role : ItemRole.values()) {
            if (findHotbarSlot(player, role) < 0) {
                missing.add(role.name() + " (not in the hotbar)");
            }
        }
        if (countTotal(player, ItemRole.ENDER_PEARL) <= 0 && !missing.contains("ENDER_PEARL (not in the hotbar)")) {
            missing.add("ENDER_PEARL (none left)");
        }
        if (countTotal(player, ItemRole.WIND_CHARGE) <= 0 && !missing.contains("WIND_CHARGE (not in the hotbar)")) {
            missing.add("WIND_CHARGE (none left)");
        }
        return missing;
    }

    /** Plain local selection. No attack, no timing guarantees. */
    public boolean selectLocal(ClientPlayerEntity player, int slot) {
        if (slot < 0 || slot >= HOTBAR_SIZE) {
            return false;
        }
        player.getInventory().setSelectedSlot(slot);
        diag.log("inventory", "selected slot " + slot + " (local)");
        return true;
    }
}
