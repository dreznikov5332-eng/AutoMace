package com.automace.inventory;

public enum ItemRole {
    ENDER_PEARL,
    WIND_CHARGE,
    SPEAR,
    MACE
}
