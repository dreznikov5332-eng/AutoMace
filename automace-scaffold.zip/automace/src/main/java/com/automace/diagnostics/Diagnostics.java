package com.automace.diagnostics;

import com.automace.config.AutoMaceConfig;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Event log (ring buffer + latest.log) and the short status line for the action bar.
 * Every entry carries the client tick number so that swap/attack timing can be reviewed later.
 */
public final class Diagnostics {
    private static final Logger LOGGER = LoggerFactory.getLogger("automace");

    public record Entry(long tick, String category, String message) {
        @Override
        public String toString() {
            return "t=" + tick + " [" + category + "] " + message;
        }
    }

    private final AutoMaceConfig config;
    private final ArrayDeque<Entry> buffer = new ArrayDeque<>();
    private long tick;

    private String lastAction = "-";
    private String lastRefusal = "-";
    private String lastVerification = "-";

    /** Own log file next to automace.json: config/automace-log.txt (cleared at every game start). */
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("automace-log.txt");

    public Diagnostics(AutoMaceConfig config) {
        this.config = config;
        try {
            Files.writeString(file, "", StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException ignored) {
        }
    }

    public void setTick(long tick) {
        this.tick = tick;
    }

    public long tick() {
        return tick;
    }

    public void log(String category, String message) {
        Entry e = new Entry(tick, category, message);
        buffer.addLast(e);
        while (buffer.size() > Math.max(10, config.diagnosticsBufferSize)) {
            buffer.removeFirst();
        }
        if (config.diagnostics) {
            LOGGER.info("[AutoMace] {}", e);
            try {
                Files.writeString(file, e + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException ignored) {
            }
        }
    }

    public void action(String category, String message) {
        lastAction = message;
        log(category, message);
    }

    public void refusal(String category, String message) {
        lastRefusal = message;
        log(category, "REFUSED: " + message);
    }

    public void verification(String category, String message) {
        lastVerification = message;
        log(category, "VERIFY: " + message);
    }

    public String lastAction() {
        return lastAction;
    }

    public String lastRefusal() {
        return lastRefusal;
    }

    public String lastVerification() {
        return lastVerification;
    }

    public List<Entry> recent() {
        return new ArrayList<>(buffer);
    }

    /** Shows a status line over the hotbar, no more than once per 5 ticks. */
    public void showStatus(ClientPlayerEntity player, String line) {
        if (!config.showStateInActionBar || tick % 5 != 0) {
            return;
        }
        player.sendMessage(Text.literal(line), true);
    }
}
