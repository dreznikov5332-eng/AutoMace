package com.automace.gui;

import com.automace.config.AutoMaceConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** In-game settings: every value changes at once (config is also saved to config/automace.json). */
public final class SettingsScreen extends Screen {
    private record Entry(String label, String field, double step, double min, double max) {
    }

    private static Entry num(String label, String field, double step, double min, double max) {
        return new Entry(label, field, step, min, max);
    }

    private static Entry flag(String label, String field) {
        return new Entry(label, field, 0, 0, 0);
    }

    private static final List<Entry> ENTRIES = List.of(
            // spear / lunges
            num("Пауза рывков в комбо (тики)", "comboLungeDelayTicks", 1, 0, 40),
            num("Пауза рывков, клавиша V (тики)", "lungeLoopDelayTicks", 1, 0, 40),
            flag("Рывок только при полном заряде", "swapRequireFullAttackCharge"),
            num("Тиков держать носитель до свапа", "swapMinCarrierHeldTicks", 1, 0, 5),
            // combo
            num("Угол жемчуга (град, вверх = минус)", "comboPearlPitch", 5, -90, -10),
            num("Мин. высота над врагом", "comboMinHeightAboveTarget", 1, 0, 60),
            num("Высота на блок дистанции", "comboHeightPerBlock", 0.1, 0, 3),
            num("Макс. дистанция до начала рывка", "comboMaxDashHorizontal", 1, 0, 40),
            num("Дистанция, где рывки заканчиваются", "comboLungeStopDistance", 0.5, 2, 20),
            num("Дистанция удара булавой", "comboMaceDistance", 0.5, 1.5, 6),
            num("Запас до удара (тики)", "comboMaceLeadTicks", 0.5, 0, 10),
            num("Скорость рывка в воздухе (блок/тик)", "comboLungeSpeedPerTick", 0.05, 0, 3),
            num("Макс. наклон вниз при рывках (град)", "comboDashMaxPitchDown", 5, 0, 90),
            num("Мин. высота для нового подъёма", "comboReascentMinHeight", 1, 0, 40),
            num("Макс. новых подъёмов", "comboMaxReascents", 1, 0, 10),
            num("Макс. перлов за подъём", "ascentCyclesMax", 1, 1, 6),
            num("Зачарование Порыв ветра на булаве (0-3)", "maceWindBurstLevel", 1, 0, 3),
            num("Высота рывка Порыв ветра I (блоки)", "windBurstHeightLevel1", 1, 0, 60),
            num("Высота рывка Порыв ветра II (блоки)", "windBurstHeightLevel2", 1, 0, 60),
            num("Высота рывка Порыв ветра III (блоки)", "windBurstHeightLevel3", 1, 0, 60),
            flag("Повторять комбо до повторного R", "comboLoop"),
            num("Пауза между повторами (тики)", "comboLoopPauseTicks", 5, 0, 200),
            num("Допустимо неудачных циклов подряд", "comboMaxCycleFailures", 1, 0, 10),
            // pearl + charge
            flag("Подброс зарядом под себя", "cycleSelfBoostEnabled"),
            num("Макс. ожидание после подброса (тики)", "cycleBoostMaxWaitTicks", 1, 0, 30),
            num("Бросать перл при верт. скорости <=", "cycleBoostPearlMaxVy", 0.05, -1, 1),
            num("Макс. ожидание перед зарядом (тики)", "cycleMaxDelayTicks", 1, 0, 30),
            num("Макс. полёт заряда (тики)", "cycleMaxFlightTicks", 1, 4, 40),
            num("Перезарядка заряда ветра (тики)", "windChargeCooldownTicks", 1, 0, 40),
            num("Мин. верт. скорость перла при ударе", "cyclePearlMinVyAtHit", 0.05, 0, 1.5),
            num("Штраф за промах в расчёте", "cycleMissPenalty", 1, 0, 30),
            num("Мин. прирост высоты (блоки)", "cycleMinScore", 0.5, 0, 30),
            num("Задержка сети в тиках (-1 = авто)", "interceptLatencyTicks", 1, -1, 10),
            // target + general
            flag("Цель: ближайший (выкл = прицел)", "autoTarget"),
            flag("Варден тоже цель (для тестов)", "targetWarden"),
            num("Макс. дистанция до цели", "maxTargetDistance", 4, 8, 256),
            flag("Только при прямой видимости", "requireLineOfSight"),
            flag("Записывать полёты (рекордер)", "flightRecorder"),
            flag("Подробный лог", "diagnostics"),
            flag("Статус над хотбаром", "showStateInActionBar"),
            flag("Мод включён", "enabled")
    );

    private static final int ROWS = 8;

    private final AutoMaceConfig config;
    private int page;
    private final List<ButtonWidget> toggles = new ArrayList<>();

    public SettingsScreen(AutoMaceConfig config) {
        super(Text.literal("AutoMace: настройки"));
        this.config = config;
    }

    @Override
    protected void init() {
        toggles.clear();
        int pages = (ENTRIES.size() + ROWS - 1) / ROWS;
        page = Math.max(0, Math.min(page, pages - 1));
        int cx = this.width / 2;
        int top = 40;
        for (int i = 0; i < ROWS; i++) {
            int idx = page * ROWS + i;
            if (idx >= ENTRIES.size()) {
                break;
            }
            Entry e = ENTRIES.get(idx);
            int y = top + i * 24;
            if (e.step() == 0) {
                ButtonWidget b = ButtonWidget.builder(Text.literal(boolText(e)), btn -> {
                    set(e, !(Boolean) get(e));
                    btn.setMessage(Text.literal(boolText(e)));
                }).dimensions(cx + 60, y, 120, 20).build();
                addDrawableChild(b);
                toggles.add(b);
            } else {
                addDrawableChild(ButtonWidget.builder(Text.literal("-"), btn -> adjust(e, -1))
                        .dimensions(cx + 60, y, 20, 20).build());
                addDrawableChild(ButtonWidget.builder(Text.literal("+"), btn -> adjust(e, 1))
                        .dimensions(cx + 160, y, 20, 20).build());
            }
        }
        int by = top + ROWS * 24 + 6;
        addDrawableChild(ButtonWidget.builder(Text.literal("< Назад"), btn -> {
            page--;
            clearAndInit();
        }).dimensions(cx - 150, by, 90, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), btn -> close())
                .dimensions(cx - 45, by, 90, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Дальше >"), btn -> {
            page++;
            clearAndInit();
        }).dimensions(cx + 60, by, 90, 20).build());
    }

    private Object get(Entry e) {
        try {
            Field f = AutoMaceConfig.class.getField(e.field());
            return f.get(config);
        } catch (Exception ex) {
            return 0;
        }
    }

    private void set(Entry e, Object v) {
        try {
            Field f = AutoMaceConfig.class.getField(e.field());
            f.set(config, v);
            config.save();
        } catch (Exception ignored) {
        }
    }

    private String boolText(Entry e) {
        return Boolean.TRUE.equals(get(e)) ? "ВКЛ" : "ВЫКЛ";
    }

    private void adjust(Entry e, int dir) {
        Object cur = get(e);
        double v = ((Number) cur).doubleValue() + dir * e.step();
        v = Math.max(e.min(), Math.min(e.max(), v));
        v = Math.round(v * 1000.0) / 1000.0;
        if (cur instanceof Integer) {
            set(e, (int) Math.round(v));
        } else if (cur instanceof Float) {
            set(e, (float) v);
        } else {
            set(e, v);
        }
    }

    private String valueText(Entry e) {
        Object v = get(e);
        if (v instanceof Integer i) {
            return Integer.toString(i);
        }
        return String.format(Locale.ROOT, "%.3f", ((Number) v).doubleValue()).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int pages = (ENTRIES.size() + ROWS - 1) / ROWS;
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("AutoMace: настройки  (стр. " + (page + 1) + "/" + pages
                + ")  значения сохраняются сразу"), cx, 14, 0xFFFFFFFF);
        for (int i = 0; i < ROWS; i++) {
            int idx = page * ROWS + i;
            if (idx >= ENTRIES.size()) {
                break;
            }
            Entry e = ENTRIES.get(idx);
            int y = 40 + i * 24;
            ctx.drawTextWithShadow(this.textRenderer, Text.literal(e.label()), cx - 215, y + 6, 0xFFE0E0E0);
            if (e.step() != 0) {
                ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(valueText(e)), cx + 120, y + 6, 0xFFFFFF55);
            }
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        config.save();
        MinecraftClient.getInstance().setScreen(null);
    }
}
