package com.automace.recorder;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.AbstractWindChargeEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Passive recorder (no control over anything): whenever an ender pearl or a wind charge exists, every tick is logged
 * with client AND server (singleplayer) positions and velocities, and every disappearance of such an entity is logged
 * with its removal reason and the distances to the other tracked entities and to the player. Used to learn what really
 * happens when the technique is performed by hand.
 */
public final class FlightRecorder {
    private static final class Info {
        Entity ref;
        String type;
        Vec3d pos = Vec3d.ZERO;
        Vec3d vel = Vec3d.ZERO;
        Vec3d srvPos;
        Vec3d srvVel;
        long firstTick;
    }

    private final AutoMaceConfig config;
    private final Diagnostics diag;
    private final Map<Integer, Info> tracked = new HashMap<>();
    private Vec3d lastPlayerPos;
    private boolean wasActive;

    public FlightRecorder(AutoMaceConfig config, Diagnostics diag) {
        this.config = config;
        this.diag = diag;
    }

    public void tick(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (!config.flightRecorder || me == null || mc.world == null) {
            tracked.clear();
            return;
        }
        ServerWorld sw = mc.getServer() == null ? null : mc.getServer().getWorld(mc.world.getRegistryKey());

        Set<Integer> present = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            boolean pearl = e instanceof EnderPearlEntity;
            boolean charge = e instanceof AbstractWindChargeEntity;
            if (!pearl && !charge) {
                continue;
            }
            int id = e.getId();
            present.add(id);
            Info in = tracked.get(id);
            if (in == null) {
                in = new Info();
                in.type = pearl ? "PEARL" : "CHARGE";
                in.firstTick = diag.tick();
                tracked.put(id, in);
                diag.log("rec", String.format("NEW %s id=%d at (%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f), player eye=(%.3f, %.3f, %.3f) look yaw=%.1f pitch=%.1f",
                        in.type, id, e.getX(), e.getY(), e.getZ(), e.getVelocity().x, e.getVelocity().y, e.getVelocity().z,
                        me.getEyePos().x, me.getEyePos().y, me.getEyePos().z, me.getYaw(), me.getPitch()));
            }
            in.ref = e;
            in.pos = new Vec3d(e.getX(), e.getY(), e.getZ());
            in.vel = e.getVelocity();
            String srv = " srv=n/a";
            if (sw != null) {
                Entity se = sw.getEntityById(id);
                if (se != null) {
                    in.srvPos = new Vec3d(se.getX(), se.getY(), se.getZ());
                    in.srvVel = se.getVelocity();
                    srv = String.format(" srv=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f)", in.srvPos.x, in.srvPos.y, in.srvPos.z,
                            in.srvVel.x, in.srvVel.y, in.srvVel.z);
                } else {
                    srv = " srv=GONE";
                }
            }
            diag.log("rec", String.format("%s id=%d age=%d pos=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f)%s",
                    in.type, id, diag.tick() - in.firstTick, in.pos.x, in.pos.y, in.pos.z, in.vel.x, in.vel.y, in.vel.z, srv));
        }

        Iterator<Map.Entry<Integer, Info>> it = tracked.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Info> en = it.next();
            if (present.contains(en.getKey())) {
                continue;
            }
            Info gone = en.getValue();
            StringBuilder sb = new StringBuilder(String.format(
                    "REMOVED %s id=%d after %d ticks, last pos=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f), reason=%s, last srv pos=%s",
                    gone.type, en.getKey(), diag.tick() - gone.firstTick, gone.pos.x, gone.pos.y, gone.pos.z,
                    gone.vel.x, gone.vel.y, gone.vel.z,
                    gone.ref == null ? "?" : String.valueOf(gone.ref.getRemovalReason()), gone.srvPos));
            for (Map.Entry<Integer, Info> o : tracked.entrySet()) {
                if (o.getKey().equals(en.getKey())) {
                    continue;
                }
                sb.append(String.format(" | distance to %s id=%d: %.3f (it is %s)", o.getValue().type, o.getKey(),
                        gone.pos.distanceTo(o.getValue().pos), present.contains(o.getKey()) ? "alive" : "also gone"));
            }
            sb.append(String.format(" | distance to the player: %.3f", gone.pos.distanceTo(new Vec3d(me.getX(), me.getY(), me.getZ()))));
            diag.log("rec", sb.toString());
            it.remove();
        }

        Vec3d pp = new Vec3d(me.getX(), me.getY(), me.getZ());
        boolean active = !tracked.isEmpty();
        if (active || wasActive) {
            Vec3d v = me.getVelocity();
            String jump = lastPlayerPos != null && lastPlayerPos.distanceTo(pp) > 3.0
                    ? String.format("  *** PLAYER JUMP %.2f blocks ***", lastPlayerPos.distanceTo(pp)) : "";
            diag.log("rec", String.format("ME pos=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f) ground=%b%s",
                    pp.x, pp.y, pp.z, v.x, v.y, v.z, me.isOnGround(), jump));
        }
        wasActive = active;
        lastPlayerPos = pp;
    }
}
