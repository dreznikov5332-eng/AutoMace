package com.automace.cycle;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import com.automace.inventory.InventoryManager;
import com.automace.inventory.ItemRole;
import com.automace.physics.InterceptSolver;
import com.automace.physics.InterceptSolver.Solution;
import com.automace.target.TargetManager;
import com.automace.tracker.PlayerStateTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.WindChargeEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Optional;
import java.util.Set;

/**
 * One ascent cycle: throw an ender pearl exactly where the crosshair looks, then plan and throw a wind charge so
 * that it hits the pearl in flight; the pearl then teleports the player to the point where it was hit.
 *
 * The moment of the charge throw is COMPUTED, not fixed: every tick the planner (InterceptSolver) looks for the
 * delay + aim that gives the farthest / highest hit. If you look upwards the pearl climbs for longer, so the planner
 * waits longer before the charge is thrown; if you look forward, the hit point is farther away.
 * Item cooldowns of the pearl and the wind charge are respected.
 *
 * Everything is logged with tick numbers so that the physics defaults in the config (drag, gravity, charge speed,
 * latency) can be checked and corrected from a real run.
 *
 * Not done here (later stages): how many cycles / what total height, and the spear lunge after the ascent.
 */
public final class PearlChargeCycle {

    private enum State { IDLE, BOOST_WAIT, WAIT_COOLDOWN, AWAIT_PEARL, SOLVING, AWAIT_RESULT }

    private final AutoMaceConfig config;
    private final Diagnostics diag;
    private final InventoryManager inventory;
    private final PlayerStateTracker tracker;

    private State state = State.IDLE;
    private long startTick;
    private long pearlThrowTick;
    private long chargeThrowTick;

    private int originalSlot = -1;
    private double yBeforeThrow;

    private final Set<Entity> ignoredPearls = Collections.newSetFromMap(new IdentityHashMap<>());
    private final Set<Entity> ignoredCharges = Collections.newSetFromMap(new IdentityHashMap<>());
    private Entity pearl;
    private Entity charge;
    private Vec3d predictedPearlNext;
    // Pearl state propagated by our own physics model. The client entity position is NOT trusted: after a throw with
    // upward player momentum (self boost) the client pearl lags the real one by several blocks (log 9dae942c),
    // while the first seen position and every velocity reading match the server.
    private Vec3d simPos;
    private Vec3d simVel;
    private Solution solution;
    private Vec3d expectedChargeVelocity = Vec3d.ZERO;
    private Vec3d lastMotion = Vec3d.ZERO;
    private boolean lastAirborne;
    private boolean chargeLogged;
    private long pearlGoneTick = -1;
    private int lastPlannedDelay = -1;
    private long lastPlanLogTick = -1000;

    public PearlChargeCycle(AutoMaceConfig config, Diagnostics diag, InventoryManager inventory,
                            TargetManager targets, PlayerStateTracker tracker) {
        this.config = config;
        this.diag = diag;
        this.inventory = inventory;
        this.tracker = tracker;
    }

    public boolean isRunning() {
        return state != State.IDLE;
    }

    // ------------------------------------------------------------------ control

    private Float aimYaw;
    private Float aimPitch;
    private boolean lastTeleported;
    private double lastHeightGain;
    private String lastEnd = "-";

    public boolean lastTeleported() {
        return lastTeleported;
    }

    public double lastHeightGain() {
        return lastHeightGain;
    }

    public String lastEnd() {
        return lastEnd;
    }

    private boolean leaveChargeSelected;
    private long boostTick;

    public void start(MinecraftClient mc) {
        leaveChargeSelected = false;
        start(mc, null, null);
    }

    /** Combo entry: the wind charge stays selected afterwards (it is the carrier of the following lunges). */
    public void startForCombo(MinecraftClient mc, Float yaw, Float pitch) {
        leaveChargeSelected = true;
        start(mc, yaw, pitch);
    }

    /** yaw / pitch may be null (= throw the pearl exactly where the crosshair looks). */
    public void start(MinecraftClient mc, Float yaw, Float pitch) {
        aimYaw = yaw;
        aimPitch = pitch;
        lastTeleported = false;
        lastHeightGain = 0.0;
        lastEnd = "-";
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null || mc.interactionManager == null) {
            return;
        }
        if (state != State.IDLE) {
            diag.refusal("cycle", "already running (" + state + ")");
            return;
        }
        if (mc.currentScreen != null) {
            diag.refusal("cycle", "a screen is open");
            return;
        }
        if (inventory.findHotbarSlot(me, ItemRole.ENDER_PEARL) < 0
                || inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE) < 0) {
            diag.refusal("cycle", "need an ender pearl and a wind charge in the hotbar");
            return;
        }

        startTick = diag.tick();
        originalSlot = me.getInventory().getSelectedSlot();
        pearl = null;
        charge = null;
        solution = null;
        chargeLogged = false;
        pearlGoneTick = -1;
        predictedPearlNext = null;
        simPos = null;
        simVel = null;
        lastPlannedDelay = -1;
        lastPlanLogTick = -1000;
        minGap = Double.MAX_VALUE;
        minGapInfo = "";
        serverChargeGoneLogged = false;
        lastServerPearl = null;
        lastServerCharge = null;

        if (config.cycleSelfBoostEnabled && me.isOnGround() && !coolingDown(me, ItemRole.WIND_CHARGE)) {
            throwBoost(mc, me);
            state = State.BOOST_WAIT;
            return;
        }
        if (coolingDown(me, ItemRole.ENDER_PEARL)) {
            if (!config.cycleWaitForCooldown) {
                diag.refusal("cycle", "ender pearl is on cooldown");
                return;
            }
            diag.log("cycle", "ender pearl on cooldown, waiting");
            state = State.WAIT_COOLDOWN;
            return;
        }
        throwPearl(mc, me);
    }

    public void cancel(String reason) {
        if (state == State.IDLE) {
            return;
        }
        diag.log("cycle", "cancelled: " + reason);
        finish(MinecraftClient.getInstance(), "cancelled");
    }

    private void finish(MinecraftClient mc, String why) {
        if (!minGapInfo.isEmpty()) {
            diag.log("cycle", "RESULT " + minGapInfo + " | end: " + why);
            minGapInfo = "";
            minGap = Double.MAX_VALUE;
        }
        if (mc != null && mc.player != null && originalSlot >= 0) {
            int keep = leaveChargeSelected ? inventory.findHotbarSlot(mc.player, ItemRole.WIND_CHARGE) : -1;
            mc.player.getInventory().setSelectedSlot(keep >= 0 ? keep : originalSlot);
        }
        lastEnd = why;
        diag.action("cycle", "finished: " + why + " (" + (diag.tick() - startTick) + " ticks)");
        state = State.IDLE;
        pearl = null;
        charge = null;
        solution = null;
    }

    private boolean coolingDown(ClientPlayerEntity me, ItemRole role) {
        int slot = inventory.findHotbarSlot(me, role);
        return slot >= 0 && me.getItemCooldownManager().isCoolingDown(me.getInventory().getStack(slot));
    }

    private void throwBoost(MinecraftClient mc, ClientPlayerEntity me) {
        int slot = inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE);
        float oldYaw = me.getYaw();
        float oldPitch = me.getPitch();
        me.getInventory().setSelectedSlot(slot);
        me.setPitch(90f);
        mc.interactionManager.interactItem(me, Hand.MAIN_HAND);
        me.setYaw(oldYaw);
        me.setPitch(oldPitch);
        boostTick = diag.tick();
        diag.action("cycle", String.format("self boost: wind charge thrown straight down at the feet, player y=%.2f", me.getY()));
    }

    /** Ticks left on the wind charge item cooldown (0 = ready). */
    private int chargeCooldownLeft(ClientPlayerEntity me) {
        int slot = inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE);
        if (slot < 0) {
            return 0;
        }
        float prog = me.getItemCooldownManager().getCooldownProgress(me.getInventory().getStack(slot), 0.0f);
        return prog <= 0f ? 0 : (int) Math.ceil(prog * config.windChargeCooldownTicks);
    }

    /** The pearl goes exactly where the crosshair looks: no aim change. */
    private void throwPearl(MinecraftClient mc, ClientPlayerEntity me) {
        ignoredPearls.clear();
        ignoredCharges.clear();
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof EnderPearlEntity) {
                ignoredPearls.add(e);
            } else if (e instanceof WindChargeEntity) {
                ignoredCharges.add(e);
            }
        }
        yBeforeThrow = me.getY();
        if (aimYaw != null) {
            me.setYaw(aimYaw);
        }
        if (aimPitch != null) {
            me.setPitch(aimPitch);
        }
        int slot = inventory.findHotbarSlot(me, ItemRole.ENDER_PEARL);
        me.getInventory().setSelectedSlot(slot);
        mc.interactionManager.interactItem(me, Hand.MAIN_HAND);
        pearlThrowTick = diag.tick();
        diag.action("cycle", String.format("pearl thrown along the crosshair: yaw=%.1f pitch=%.1f, player y=%.2f vy=%.3f",
                me.getYaw(), me.getPitch(), me.getY(), me.getVelocity().y));
        state = State.AWAIT_PEARL;
    }

    // ------------------------------------------------------------------ tick (end of client tick)

    public void tick(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (state == State.IDLE) {
            return;
        }
        if (me == null || mc.world == null) {
            state = State.IDLE;
            return;
        }
        if (me.isDead() || me.getHealth() <= 0f) {
            finish(mc, "player died");
            return;
        }
        long now = diag.tick();
        if (now - startTick > config.cycleTimeoutTicks) {
            finish(mc, "timeout");
            return;
        }

        if (state == State.BOOST_WAIT) {
            // the pearl inherits the player's vertical momentum (pearl ~2.3 b/tick) and then no charge can catch it,
            // so the pearl is thrown at the top of the boost jump
            if (now - boostTick >= config.cycleBoostMaxWaitTicks
                    || (now - boostTick >= 2 && me.getVelocity().y <= config.cycleBoostPearlMaxVy)) {
                if (coolingDown(me, ItemRole.ENDER_PEARL)) {
                    state = State.WAIT_COOLDOWN;
                } else {
                    throwPearl(mc, me);
                }
            }
            return;
        }

        if (state == State.WAIT_COOLDOWN) {
            if (!coolingDown(me, ItemRole.ENDER_PEARL)) {
                throwPearl(mc, me);
            }
            return;
        }

        scanEntities(mc, me);

        switch (state) {
            case AWAIT_PEARL -> {
                if (pearl != null) {
                    state = State.SOLVING;
                    plan(mc, me);
                } else if (now - pearlThrowTick > 10) {
                    finish(mc, "no pearl entity appeared near the player");
                }
            }
            case SOLVING -> {
                logPearlAccuracy();
                if (pearl == null || !pearl.isAlive()) {
                    finish(mc, "pearl is gone before the charge was thrown");
                    return;
                }
                plan(mc, me);
            }
            case AWAIT_RESULT -> awaitResult(mc, me, now);
            default -> { }
        }
        trace(me, now);
    }

    private Vec3d lastServerPearl;
    private Vec3d lastServerCharge;
    private boolean serverChargeGoneLogged;

    /** Singleplayer only: the real (server side) positions of the pearl and the charge, to compare with the client view. */
    private String serverTruth() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getServer() == null || mc.world == null) {
            return " | server=n/a";
        }
        net.minecraft.server.world.ServerWorld sw = mc.getServer().getWorld(mc.world.getRegistryKey());
        if (sw == null) {
            return " | server=n/a";
        }
        StringBuilder sb = new StringBuilder(" | SRV");
        if (pearl != null) {
            Entity sp = sw.getEntityById(pearl.getId());
            if (sp != null) {
                Vec3d v = sp.getVelocity();
                lastServerPearl = new Vec3d(sp.getX(), sp.getY(), sp.getZ());
                sb.append(String.format(" pearl=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f)", sp.getX(), sp.getY(), sp.getZ(), v.x, v.y, v.z));
            } else {
                sb.append(" pearl=GONE(last ").append(lastServerPearl).append(")");
            }
        }
        if (charge != null) {
            Entity sc = sw.getEntityById(charge.getId());
            if (sc != null) {
                Vec3d v = sc.getVelocity();
                lastServerCharge = new Vec3d(sc.getX(), sc.getY(), sc.getZ());
                sb.append(String.format(" charge=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f)", sc.getX(), sc.getY(), sc.getZ(), v.x, v.y, v.z));
            } else {
                sb.append(" charge=GONE(last ").append(lastServerCharge).append(")");
                if (!serverChargeGoneLogged) {
                    serverChargeGoneLogged = true;
                    diag.log("cycle", "SERVER: the wind charge is gone, last server pos " + lastServerCharge
                            + ", last server pearl pos " + lastServerPearl);
                }
            }
        }
        return sb.toString();
    }

    private double minGap = Double.MAX_VALUE;
    private String minGapInfo = "";

    /** Per-tick record of everything needed to calibrate the model from a single log. */
    private void trace(ClientPlayerEntity me, long now) {
        Vec3d pv = me.getVelocity();
        StringBuilder sb = new StringBuilder(String.format(
                "TRACE +%d me=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f) ground=%b",
                now - pearlThrowTick, me.getX(), me.getY(), me.getZ(), pv.x, pv.y, pv.z, me.isOnGround()));
        if (pearl != null && pearl.isAlive()) {
            Vec3d v = pearl.getVelocity();
            sb.append(String.format(" | pearl=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f)",
                    pearl.getX(), pearl.getY(), pearl.getZ(), v.x, v.y, v.z));
        }
        if (charge != null && charge.isAlive()) {
            Vec3d v = charge.getVelocity();
            sb.append(String.format(" | charge=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f)",
                    charge.getX(), charge.getY(), charge.getZ(), v.x, v.y, v.z));
            if (pearl != null && pearl.isAlive()) {
                Vec3d pp = simPos != null ? simPos : new Vec3d(pearl.getX(), pearl.getY(), pearl.getZ());
                double dx = charge.getX() - pp.x;
                double dy = charge.getY() - pp.y;
                double dz = charge.getZ() - pp.z;
                double gap = Math.sqrt(dx * dx + dy * dy + dz * dz);
                sb.append(String.format(" | gap=(%.3f, %.3f, %.3f) dist=%.3f", dx, dy, dz, gap));
                if (gap < minGap) {
                    minGap = gap;
                    minGapInfo = String.format("closest approach +%d: charge minus pearl = (%.3f, %.3f, %.3f), dist=%.3f",
                            now - pearlThrowTick, dx, dy, dz, gap);
                }
            }
        }
        sb.append(serverTruth());
        diag.log("trace", sb.toString());
    }

    /** Finds the pearl / charge that belong to this cycle: new entities close to the player's eye. */
    private void scanEntities(MinecraftClient mc, ClientPlayerEntity me) {
        Vec3d eye = me.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (pearl == null && e instanceof EnderPearlEntity && !ignoredPearls.contains(e)
                    && eye.distanceTo(new Vec3d(e.getX(), e.getY(), e.getZ())) < 4.0) {
                pearl = e;
                ignoredPearls.add(e);
                Vec3d v = e.getVelocity();
                diag.log("cycle", String.format("pearl entity seen at t=%d (+%d): pos=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) speed=%.3f",
                        diag.tick(), diag.tick() - pearlThrowTick, e.getX(), e.getY(), e.getZ(), v.x, v.y, v.z, v.length()));
            }
            if (state == State.AWAIT_RESULT && charge == null && e instanceof WindChargeEntity
                    && !ignoredCharges.contains(e)
                    && eye.distanceTo(new Vec3d(e.getX(), e.getY(), e.getZ())) < 4.0) {
                charge = e;
                ignoredCharges.add(e);
            }
        }
    }

    private int latencyTicks(MinecraftClient mc, ClientPlayerEntity me) {
        int latency = config.interceptLatencyTicks;
        if (latency < 0) {
            latency = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(me.getNameForScoreboard());
                if (entry != null) {
                    latency = (int) Math.max(0, Math.min(10, Math.round(entry.getLatency() / 50.0)));
                }
            }
        }
        return latency;
    }

    private InterceptSolver.Params buildParams(ClientPlayerEntity me, int latency, int minDelay) {
        double radius = (config.pearlHitboxWidth + config.windChargeHitboxWidth) / 2.0 + config.interceptHitMargin;
        return new InterceptSolver.Params(config.pearlDrag, config.pearlGravity,
                config.windChargeSpeed, config.windChargeGravity, config.windChargeInheritsMomentum,
                radius, latency, config.cycleMaxDelayTicks, config.cycleMaxFlightTicks,
                me.getY() + config.cycleMinImpactAboveFeet, config.cycleMinScore,
                config.cycleHeightWeight, config.cycleDistanceWeight,
                config.playerGravity, config.playerVerticalDrag, config.cyclePearlMinVyAtHit,
                config.cycleMissPenalty, minDelay);
    }

    /**
     * Chooses the pearl pitch (towards yaw) so that the teleport point lands as close as possible to the given horizontal
     * distance from the player while still gaining at least minGain blocks. The pearl start state is modelled from the
     * measured log: spawn 0.1 below the eye, launch speed 1.5 along the look direction plus the player's momentum,
     * one tick of drag/gravity already applied when it is first seen.
     * Returns null when no pitch gives a plan.
     */
    public Float suggestPitch(MinecraftClient mc, ClientPlayerEntity me, float yaw, double horizontalDistance, double minGain) {
        int latency = latencyTicks(mc, me);
        InterceptSolver.Params prm = buildParams(me, latency, 0);
        Vec3d eye = me.getEyePos();
        boolean airborne = !me.isOnGround();
        Vec3d motion = Vec3d.ZERO;
        PlayerStateTracker.Snapshot cur = tracker.current();
        PlayerStateTracker.Snapshot prev = tracker.previous();
        if (cur != null && prev != null) {
            motion = cur.pos().subtract(prev.pos());
        }
        Vec3d momentum = new Vec3d(motion.x, airborne ? motion.y : 0.0, motion.z);
        Vec3d origin = new Vec3d(me.getX(), me.getY(), me.getZ());
        double yawRad = Math.toRadians(yaw);
        Float bestPitch = null;
        double bestErr = Double.MAX_VALUE;
        double bestGain = 0;
        for (int pitch = -90; pitch <= -25; pitch += 5) {
            double pr = Math.toRadians(pitch);
            Vec3d dir = new Vec3d(-Math.sin(yawRad) * Math.cos(pr), -Math.sin(pr), Math.cos(yawRad) * Math.cos(pr));
            Vec3d v0 = dir.multiply(1.5).add(momentum);
            Vec3d v1 = new Vec3d(v0.x * config.pearlDrag, v0.y * config.pearlDrag - config.pearlGravity, v0.z * config.pearlDrag);
            Vec3d p1 = new Vec3d(eye.x, eye.y - 0.1, eye.z).add(v1);
            Optional<Solution> sol = InterceptSolver.solve(p1, v1, eye, motion, airborne, origin, prm);
            if (sol.isEmpty() || sol.get().heightGain() < minGain) {
                continue;
            }
            Vec3d ip = sol.get().impactPoint();
            double h = Math.sqrt((ip.x - origin.x) * (ip.x - origin.x) + (ip.z - origin.z) * (ip.z - origin.z));
            double err = Math.abs(h - horizontalDistance);
            if (err < bestErr) {
                bestErr = err;
                bestPitch = (float) pitch;
                bestGain = sol.get().heightGain();
            }
        }
        diag.log("cycle", String.format("pitch suggestion for horizontal distance %.1f: %s (error %.1f, expected gain %.1f)",
                horizontalDistance, bestPitch, bestErr, bestGain));
        return bestPitch;
    }

    /** Re-plans every tick. The charge is thrown when the best plan says "now" (delay 0). */
    private void plan(MinecraftClient mc, ClientPlayerEntity me) {
        if (simPos == null) {
            simPos = new Vec3d(pearl.getX(), pearl.getY(), pearl.getZ());
            simVel = pearl.getVelocity();
        }
        Vec3d pos = simPos;
        Vec3d vel = simVel;
        predictedPearlNext = pos.add(new Vec3d(vel.x * config.pearlDrag, vel.y * config.pearlDrag - config.pearlGravity, vel.z * config.pearlDrag));

        int latency = latencyTicks(mc, me);
        // the wind charge item cooldown: no throw is planned inside it (the cooldown value from the item, 10 ticks assumed)
        InterceptSolver.Params prm = buildParams(me, latency, Math.max(0, chargeCooldownLeft(me) - latency));

        Vec3d origin = new Vec3d(me.getX(), me.getY(), me.getZ());
        // the player's real movement over the last tick (running), not the client "velocity" field
        Vec3d motion = Vec3d.ZERO;
        boolean airborne = !me.isOnGround();
        PlayerStateTracker.Snapshot cur = tracker.current();
        PlayerStateTracker.Snapshot prev = tracker.previous();
        if (cur != null && prev != null) {
            motion = cur.pos().subtract(prev.pos());
        }
        lastMotion = motion;
        lastAirborne = airborne;
        Optional<Solution> sol = InterceptSolver.solve(pos, vel, me.getEyePos(), motion, airborne, origin, prm);
        long now = diag.tick();
        if (sol.isEmpty()) {
            if (now - lastPlanLogTick >= 10) {
                lastPlanLogTick = now;
                diag.log("cycle", String.format("no hit plan yet: pearl=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) latency=%d",
                        pos.x, pos.y, pos.z, vel.x, vel.y, vel.z, latency));
            }
            return;
        }

        solution = sol.get();
        if (solution.delayTicks() != lastPlannedDelay || now - lastPlanLogTick >= 10) {
            lastPlannedDelay = solution.delayTicks();
            lastPlanLogTick = now;
            diag.log("cycle", String.format("plan: throw the charge in %d tick(s), flight %d, impact=(%.2f, %.2f, %.2f), height gain=%.2f, score=%.2f, miss=%.3f, latency=%d, player motion=(%.3f, %.3f, %.3f)",
                    solution.delayTicks(), solution.flightTicks(), solution.impactPoint().x, solution.impactPoint().y,
                    solution.impactPoint().z, solution.heightGain(), solution.score(), solution.missDistance(), latency,
                    motion.x, motion.y, motion.z));
        }
        if (solution.delayTicks() > 0) {
            return; // the pearl is given more time to climb / fly
        }

        if (coolingDown(me, ItemRole.WIND_CHARGE)) {
            diag.log("cycle", "plan says throw now, but the wind charge is on cooldown, waiting");
            return;
        }
        throwCharge(mc, me, pos);
    }

    private void throwCharge(MinecraftClient mc, ClientPlayerEntity me, Vec3d pearlPos) {
        Vec3d d = solution.aimDirection();
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.asin(Math.max(-1.0, Math.min(1.0, d.y))));
        int chargeSlot = inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE);
        if (chargeSlot < 0) {
            finish(mc, "wind charge disappeared from the hotbar");
            return;
        }
        Vec3d momentum = config.windChargeInheritsMomentum
                ? new Vec3d(lastMotion.x, lastAirborne ? lastMotion.y : 0.0, lastMotion.z) : Vec3d.ZERO;
        expectedChargeVelocity = d.multiply(config.windChargeSpeed).add(momentum);
        float oldYaw = me.getYaw();
        float oldPitch = me.getPitch();
        me.getInventory().setSelectedSlot(chargeSlot);
        me.setYaw(yaw);
        me.setPitch(pitch);
        mc.interactionManager.interactItem(me, Hand.MAIN_HAND);
        me.setYaw(oldYaw);
        me.setPitch(oldPitch);

        chargeThrowTick = diag.tick();
        diag.action("cycle", String.format(
                "charge thrown at t=%d (%d ticks after the pearl): aim yaw=%.1f pitch=%.1f | expected impact=(%.2f, %.2f, %.2f) in %d ticks, miss=%.3f | pearl is at (%.2f, %.2f, %.2f)",
                chargeThrowTick, chargeThrowTick - pearlThrowTick, yaw, pitch, solution.impactPoint().x,
                solution.impactPoint().y, solution.impactPoint().z, solution.flightTicks(), solution.missDistance(),
                pearlPos.x, pearlPos.y, pearlPos.z));
        state = State.AWAIT_RESULT;
    }

    private void awaitResult(MinecraftClient mc, ClientPlayerEntity me, long now) {
        logPearlAccuracy();

        if (charge != null && !chargeLogged) {
            chargeLogged = true;
            Vec3d v = charge.getVelocity();
            diag.log("cycle", String.format("charge entity seen at t=%d (+%d): pos=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) speed=%.3f | expected vel=(%.3f, %.3f, %.3f) speed=%.3f",
                    now, now - chargeThrowTick, charge.getX(), charge.getY(), charge.getZ(),
                    v.x, v.y, v.z, v.length(), expectedChargeVelocity.x, expectedChargeVelocity.y,
                    expectedChargeVelocity.z, expectedChargeVelocity.length()));
        }

        if (tracker.lastTeleportSuspectedTick() >= chargeThrowTick) {
            Vec3d now3 = new Vec3d(me.getX(), me.getY(), me.getZ());
            diag.verification("cycle", String.format(
                    "TELEPORT detected at t=%d (+%d after the charge throw): new pos=(%.2f, %.2f, %.2f), height gain=%.2f, expected impact=(%.2f, %.2f, %.2f)",
                    tracker.lastTeleportSuspectedTick(), tracker.lastTeleportSuspectedTick() - chargeThrowTick,
                    now3.x, now3.y, now3.z, now3.y - yBeforeThrow,
                    solution.impactPoint().x, solution.impactPoint().y, solution.impactPoint().z));
            lastTeleported = true;
            lastHeightGain = now3.y - yBeforeThrow;
            finish(mc, "teleported, height gain " + String.format("%.2f", now3.y - yBeforeThrow));
            return;
        }

        if (pearl == null || !pearl.isAlive()) {
            if (pearlGoneTick < 0) {
                pearlGoneTick = now;
                diag.log("cycle", "pearl entity is gone at t=" + now);
            } else if (now - pearlGoneTick >= 3) {
                diag.verification("cycle", "pearl ended without a teleport signal (charge missed or pearl hit something else)");
                finish(mc, "no teleport");
            }
        }
    }

    /** Logs how far the real pearl is from where the physics model predicted it one tick ago. */
    private void logPearlAccuracy() {
        if (pearl == null || !pearl.isAlive()) {
            return;
        }
        Vec3d actual = new Vec3d(pearl.getX(), pearl.getY(), pearl.getZ());
        if (simPos != null) {
            simVel = new Vec3d(simVel.x * config.pearlDrag, simVel.y * config.pearlDrag - config.pearlGravity, simVel.z * config.pearlDrag);
            simPos = simPos.add(simVel);
            Vec3d cv = pearl.getVelocity();
            if (config.diagnostics && simVel.distanceTo(cv) > 0.05) {
                diag.log("cycle", String.format("sim velocity differs from the entity: sim=(%.3f, %.3f, %.3f) entity=(%.3f, %.3f, %.3f)",
                        simVel.x, simVel.y, simVel.z, cv.x, cv.y, cv.z));
            }
            if (config.diagnostics) {
                diag.log("cycle", String.format("client pearl lag %.2f (client=(%.2f, %.2f, %.2f) sim=(%.2f, %.2f, %.2f))",
                        actual.distanceTo(simPos), actual.x, actual.y, actual.z, simPos.x, simPos.y, simPos.z));
            }
            return;
        }
        if (predictedPearlNext != null && config.diagnostics) {
            double err = actual.distanceTo(predictedPearlNext);
            if (err > 0.02) {
                diag.log("cycle", String.format("pearl model error %.3f (actual=(%.2f, %.2f, %.2f), predicted=(%.2f, %.2f, %.2f))",
                        err, actual.x, actual.y, actual.z, predictedPearlNext.x, predictedPearlNext.y, predictedPearlNext.z));
            }
        }
        Vec3d pv = pearl.getVelocity();
        predictedPearlNext = actual.add(new Vec3d(pv.x * config.pearlDrag, pv.y * config.pearlDrag - config.pearlGravity, pv.z * config.pearlDrag));
    }
}
