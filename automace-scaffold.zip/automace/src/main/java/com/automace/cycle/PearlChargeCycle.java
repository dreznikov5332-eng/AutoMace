package com.automace.cycle;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import com.automace.inventory.InventoryManager;
import com.automace.inventory.ItemRole;
import com.automace.physics.InterceptSolver;
import com.automace.physics.InterceptSolver.Solution;
import com.automace.target.TargetManager;
import com.automace.tracker.PlayerStateTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.WindChargeEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Optional;
import java.util.Set;

/**
 * One ascent cycle: throw an ender pearl exactly where the crosshair looks, then plan and throw a wind charge so
 * that it hits the pearl in flight; the pearl then teleports the player to the point where it was hit.
 *
 * The moment of the charge throw is COMPUTED, not fixed: every tick the planner (InterceptSolver) looks for the
 * delay + aim that gives the farthest / highest hit. If you look upwards the pearl climbs for longer, so the planner
 * waits longer before the charge is thrown; if you look forward, the hit point is farther away.
 * Item cooldowns of the pearl and the wind charge are respected.
 *
 * Everything is logged with tick numbers so that the physics defaults in the config (drag, gravity, charge speed,
 * latency) can be checked and corrected from a real run.
 *
 * Not done here (later stages): how many cycles / what total height, and the spear lunge after the ascent.
 */
public final class PearlChargeCycle {

    private enum State { IDLE, WAIT_COOLDOWN, AWAIT_PEARL, SOLVING, AWAIT_RESULT }

    private final AutoMaceConfig config;
    private final Diagnostics diag;
    private final InventoryManager inventory;
    private final PlayerStateTracker tracker;

    private State state = State.IDLE;
    private long startTick;
    private long pearlThrowTick;
    private long chargeThrowTick;

    private int originalSlot = -1;
    private double yBeforeThrow;

    private final Set<Entity> ignoredPearls = Collections.newSetFromMap(new IdentityHashMap<>());
    private final Set<Entity> ignoredCharges = Collections.newSetFromMap(new IdentityHashMap<>());
    private Entity pearl;
    private Entity charge;
    private Vec3d predictedPearlNext;
    private Solution solution;
    private Vec3d expectedChargeVelocity = Vec3d.ZERO;
    private Vec3d lastMotion = Vec3d.ZERO;
    private boolean lastAirborne;
    private boolean chargeLogged;
    private long pearlGoneTick = -1;
    private int lastPlannedDelay = -1;
    private long lastPlanLogTick = -1000;

    public PearlChargeCycle(AutoMaceConfig config, Diagnostics diag, InventoryManager inventory,
                            TargetManager targets, PlayerStateTracker tracker) {
        this.config = config;
        this.diag = diag;
        this.inventory = inventory;
        this.tracker = tracker;
    }

    public boolean isRunning() {
        return state != State.IDLE;
    }

    // ------------------------------------------------------------------ control

    private Float aimYaw;
    private Float aimPitch;
    private boolean lastTeleported;
    private double lastHeightGain;
    private String lastEnd = "-";

    public boolean lastTeleported() {
        return lastTeleported;
    }

    public double lastHeightGain() {
        return lastHeightGain;
    }

    public String lastEnd() {
        return lastEnd;
    }

    public void start(MinecraftClient mc) {
        start(mc, null, null);
    }

    /** yaw / pitch may be null (= throw the pearl exactly where the crosshair looks). */
    public void start(MinecraftClient mc, Float yaw, Float pitch) {
        aimYaw = yaw;
        aimPitch = pitch;
        lastTeleported = false;
        lastHeightGain = 0.0;
        lastEnd = "-";
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null || mc.interactionManager == null) {
            return;
        }
        if (state != State.IDLE) {
            diag.refusal("cycle", "already running (" + state + ")");
            return;
        }
        if (mc.currentScreen != null) {
            diag.refusal("cycle", "a screen is open");
            return;
        }
        if (inventory.findHotbarSlot(me, ItemRole.ENDER_PEARL) < 0
                || inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE) < 0) {
            diag.refusal("cycle", "need an ender pearl and a wind charge in the hotbar");
            return;
        }

        startTick = diag.tick();
        originalSlot = me.getInventory().getSelectedSlot();
        pearl = null;
        charge = null;
        solution = null;
        chargeLogged = false;
        pearlGoneTick = -1;
        predictedPearlNext = null;
        lastPlannedDelay = -1;
        lastPlanLogTick = -1000;
        minGap = Double.MAX_VALUE;
        minGapInfo = "";

        if (coolingDown(me, ItemRole.ENDER_PEARL)) {
            if (!config.cycleWaitForCooldown) {
                diag.refusal("cycle", "ender pearl is on cooldown");
                return;
            }
            diag.log("cycle", "ender pearl on cooldown, waiting");
            state = State.WAIT_COOLDOWN;
            return;
        }
        throwPearl(mc, me);
    }

    public void cancel(String reason) {
        if (state == State.IDLE) {
            return;
        }
        diag.log("cycle", "cancelled: " + reason);
        finish(MinecraftClient.getInstance(), "cancelled");
    }

    private void finish(MinecraftClient mc, String why) {
        if (!minGapInfo.isEmpty()) {
            diag.log("cycle", "RESULT " + minGapInfo + " | end: " + why);
            minGapInfo = "";
            minGap = Double.MAX_VALUE;
        }
        if (mc != null && mc.player != null && originalSlot >= 0) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        lastEnd = why;
        diag.action("cycle", "finished: " + why + " (" + (diag.tick() - startTick) + " ticks)");
        state = State.IDLE;
        pearl = null;
        charge = null;
        solution = null;
    }

    private boolean coolingDown(ClientPlayerEntity me, ItemRole role) {
        int slot = inventory.findHotbarSlot(me, role);
        return slot >= 0 && me.getItemCooldownManager().isCoolingDown(me.getInventory().getStack(slot));
    }

    /** The pearl goes exactly where the crosshair looks: no aim change. */
    private void throwPearl(MinecraftClient mc, ClientPlayerEntity me) {
        ignoredPearls.clear();
        ignoredCharges.clear();
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof EnderPearlEntity) {
                ignoredPearls.add(e);
            } else if (e instanceof WindChargeEntity) {
                ignoredCharges.add(e);
            }
        }
        yBeforeThrow = me.getY();
        if (aimYaw != null) {
            me.setYaw(aimYaw);
        }
        if (aimPitch != null) {
            me.setPitch(aimPitch);
        }
        int slot = inventory.findHotbarSlot(me, ItemRole.ENDER_PEARL);
        me.getInventory().setSelectedSlot(slot);
        mc.interactionManager.interactItem(me, Hand.MAIN_HAND);
        pearlThrowTick = diag.tick();
        diag.action("cycle", String.format("pearl thrown along the crosshair: yaw=%.1f pitch=%.1f, player y=%.2f vy=%.3f",
                me.getYaw(), me.getPitch(), me.getY(), me.getVelocity().y));
        state = State.AWAIT_PEARL;
    }

    // ------------------------------------------------------------------ tick (end of client tick)

    public void tick(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (state == State.IDLE) {
            return;
        }
        if (me == null || mc.world == null) {
            state = State.IDLE;
            return;
        }
        if (me.isDead() || me.getHealth() <= 0f) {
            finish(mc, "player died");
            return;
        }
        long now = diag.tick();
        if (now - startTick > config.cycleTimeoutTicks) {
            finish(mc, "timeout");
            return;
        }

        if (state == State.WAIT_COOLDOWN) {
            if (!coolingDown(me, ItemRole.ENDER_PEARL)) {
                throwPearl(mc, me);
            }
            return;
        }

        scanEntities(mc, me);

        switch (state) {
            case AWAIT_PEARL -> {
                if (pearl != null) {
                    state = State.SOLVING;
                    plan(mc, me);
                } else if (now - pearlThrowTick > 10) {
                    finish(mc, "no pearl entity appeared near the player");
                }
            }
            case SOLVING -> {
                logPearlAccuracy();
                if (pearl == null || !pearl.isAlive()) {
                    finish(mc, "pearl is gone before the charge was thrown");
                    return;
                }
                plan(mc, me);
            }
            case AWAIT_RESULT -> awaitResult(mc, me, now);
            default -> { }
        }
        trace(me, now);
    }

    private double minGap = Double.MAX_VALUE;
    private String minGapInfo = "";

    /** Per-tick record of everything needed to calibrate the model from a single log. */
    private void trace(ClientPlayerEntity me, long now) {
        Vec3d pv = me.getVelocity();
        StringBuilder sb = new StringBuilder(String.format(
                "TRACE +%d me=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f) ground=%b",
                now - pearlThrowTick, me.getX(), me.getY(), me.getZ(), pv.x, pv.y, pv.z, me.isOnGround()));
        if (pearl != null && pearl.isAlive()) {
            Vec3d v = pearl.getVelocity();
            sb.append(String.format(" | pearl=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f)",
                    pearl.getX(), pearl.getY(), pearl.getZ(), v.x, v.y, v.z));
        }
        if (charge != null && charge.isAlive()) {
            Vec3d v = charge.getVelocity();
            sb.append(String.format(" | charge=(%.3f, %.3f, %.3f) v=(%.3f, %.3f, %.3f)",
                    charge.getX(), charge.getY(), charge.getZ(), v.x, v.y, v.z));
            if (pearl != null && pearl.isAlive()) {
                double dx = charge.getX() - pearl.getX();
                double dy = charge.getY() - pearl.getY();
                double dz = charge.getZ() - pearl.getZ();
                double gap = Math.sqrt(dx * dx + dy * dy + dz * dz);
                sb.append(String.format(" | gap=(%.3f, %.3f, %.3f) dist=%.3f", dx, dy, dz, gap));
                if (gap < minGap) {
                    minGap = gap;
                    minGapInfo = String.format("closest approach +%d: charge minus pearl = (%.3f, %.3f, %.3f), dist=%.3f",
                            now - pearlThrowTick, dx, dy, dz, gap);
                }
            }
        }
        diag.log("trace", sb.toString());
    }

    /** Finds the pearl / charge that belong to this cycle: new entities close to the player's eye. */
    private void scanEntities(MinecraftClient mc, ClientPlayerEntity me) {
        Vec3d eye = me.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (pearl == null && e instanceof EnderPearlEntity && !ignoredPearls.contains(e)
                    && eye.distanceTo(new Vec3d(e.getX(), e.getY(), e.getZ())) < 4.0) {
                pearl = e;
                ignoredPearls.add(e);
                Vec3d v = e.getVelocity();
                diag.log("cycle", String.format("pearl entity seen at t=%d (+%d): pos=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) speed=%.3f",
                        diag.tick(), diag.tick() - pearlThrowTick, e.getX(), e.getY(), e.getZ(), v.x, v.y, v.z, v.length()));
            }
            if (state == State.AWAIT_RESULT && charge == null && e instanceof WindChargeEntity
                    && !ignoredCharges.contains(e)
                    && eye.distanceTo(new Vec3d(e.getX(), e.getY(), e.getZ())) < 4.0) {
                charge = e;
                ignoredCharges.add(e);
            }
        }
    }

    /** Re-plans every tick. The charge is thrown when the best plan says "now" (delay 0). */
    private void plan(MinecraftClient mc, ClientPlayerEntity me) {
        Vec3d pos = new Vec3d(pearl.getX(), pearl.getY(), pearl.getZ());
        Vec3d vel = pearl.getVelocity();
        predictedPearlNext = pos.add(vel);

        int latency = config.interceptLatencyTicks;
        if (latency < 0) {
            latency = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(me.getNameForScoreboard());
                if (entry != null) {
                    latency = (int) Math.max(0, Math.min(10, Math.round(entry.getLatency() / 50.0)));
                }
            }
        }

        double radius = (config.pearlHitboxWidth + config.windChargeHitboxWidth) / 2.0 + config.interceptHitMargin;
        InterceptSolver.Params prm = new InterceptSolver.Params(config.pearlDrag, config.pearlGravity,
                config.windChargeSpeed, config.windChargeGravity, config.windChargeInheritsMomentum,
                radius, latency, config.interceptMaxDelayTicks, config.interceptMaxFlightTicks,
                me.getY() + config.cycleMinImpactAboveFeet, config.cycleMinScore,
                config.cycleHeightWeight, config.cycleDistanceWeight,
                config.playerGravity, config.playerVerticalDrag);

        Vec3d origin = new Vec3d(me.getX(), me.getY(), me.getZ());
        // the player's real movement over the last tick (running), not the client "velocity" field
        Vec3d motion = Vec3d.ZERO;
        boolean airborne = !me.isOnGround();
        PlayerStateTracker.Snapshot cur = tracker.current();
        PlayerStateTracker.Snapshot prev = tracker.previous();
        if (cur != null && prev != null) {
            motion = cur.pos().subtract(prev.pos());
        }
        lastMotion = motion;
        lastAirborne = airborne;
        Optional<Solution> sol = InterceptSolver.solve(pos, vel, me.getEyePos(), motion, airborne, origin, prm);
        long now = diag.tick();
        if (sol.isEmpty()) {
            if (now - lastPlanLogTick >= 10) {
                lastPlanLogTick = now;
                diag.log("cycle", String.format("no hit plan yet: pearl=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) latency=%d",
                        pos.x, pos.y, pos.z, vel.x, vel.y, vel.z, latency));
            }
            return;
        }

        solution = sol.get();
        if (solution.delayTicks() != lastPlannedDelay || now - lastPlanLogTick >= 10) {
            lastPlannedDelay = solution.delayTicks();
            lastPlanLogTick = now;
            diag.log("cycle", String.format("plan: throw the charge in %d tick(s), flight %d, impact=(%.2f, %.2f, %.2f), height gain=%.2f, score=%.2f, miss=%.3f, latency=%d, player motion=(%.3f, %.3f, %.3f)",
                    solution.delayTicks(), solution.flightTicks(), solution.impactPoint().x, solution.impactPoint().y,
                    solution.impactPoint().z, solution.heightGain(), solution.score(), solution.missDistance(), latency,
                    motion.x, motion.y, motion.z));
        }
        if (solution.delayTicks() > 0) {
            return; // the pearl is given more time to climb / fly
        }

        if (coolingDown(me, ItemRole.WIND_CHARGE)) {
            diag.log("cycle", "plan says throw now, but the wind charge is on cooldown, waiting");
            return;
        }
        throwCharge(mc, me, pos);
    }

    private void throwCharge(MinecraftClient mc, ClientPlayerEntity me, Vec3d pearlPos) {
        Vec3d d = solution.aimDirection();
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.asin(Math.max(-1.0, Math.min(1.0, d.y))));
        int chargeSlot = inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE);
        if (chargeSlot < 0) {
            finish(mc, "wind charge disappeared from the hotbar");
            return;
        }
        Vec3d momentum = config.windChargeInheritsMomentum
                ? new Vec3d(lastMotion.x, lastAirborne ? lastMotion.y : 0.0, lastMotion.z) : Vec3d.ZERO;
        expectedChargeVelocity = d.multiply(config.windChargeSpeed).add(momentum);
        float oldYaw = me.getYaw();
        float oldPitch = me.getPitch();
        me.getInventory().setSelectedSlot(chargeSlot);
        me.setYaw(yaw);
        me.setPitch(pitch);
        mc.interactionManager.interactItem(me, Hand.MAIN_HAND);
        me.setYaw(oldYaw);
        me.setPitch(oldPitch);

        chargeThrowTick = diag.tick();
        diag.action("cycle", String.format(
                "charge thrown at t=%d (%d ticks after the pearl): aim yaw=%.1f pitch=%.1f | expected impact=(%.2f, %.2f, %.2f) in %d ticks, miss=%.3f | pearl is at (%.2f, %.2f, %.2f)",
                chargeThrowTick, chargeThrowTick - pearlThrowTick, yaw, pitch, solution.impactPoint().x,
                solution.impactPoint().y, solution.impactPoint().z, solution.flightTicks(), solution.missDistance(),
                pearlPos.x, pearlPos.y, pearlPos.z));
        state = State.AWAIT_RESULT;
    }

    private void awaitResult(MinecraftClient mc, ClientPlayerEntity me, long now) {
        logPearlAccuracy();

        if (charge != null && !chargeLogged) {
            chargeLogged = true;
            Vec3d v = charge.getVelocity();
            diag.log("cycle", String.format("charge entity seen at t=%d (+%d): pos=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) speed=%.3f | expected vel=(%.3f, %.3f, %.3f) speed=%.3f",
                    now, now - chargeThrowTick, charge.getX(), charge.getY(), charge.getZ(),
                    v.x, v.y, v.z, v.length(), expectedChargeVelocity.x, expectedChargeVelocity.y,
                    expectedChargeVelocity.z, expectedChargeVelocity.length()));
        }

        if (tracker.lastTeleportSuspectedTick() >= chargeThrowTick) {
            Vec3d now3 = new Vec3d(me.getX(), me.getY(), me.getZ());
            diag.verification("cycle", String.format(
                    "TELEPORT detected at t=%d (+%d after the charge throw): new pos=(%.2f, %.2f, %.2f), height gain=%.2f, expected impact=(%.2f, %.2f, %.2f)",
                    tracker.lastTeleportSuspectedTick(), tracker.lastTeleportSuspectedTick() - chargeThrowTick,
                    now3.x, now3.y, now3.z, now3.y - yBeforeThrow,
                    solution.impactPoint().x, solution.impactPoint().y, solution.impactPoint().z));
            lastTeleported = true;
            lastHeightGain = now3.y - yBeforeThrow;
            finish(mc, "teleported, height gain " + String.format("%.2f", now3.y - yBeforeThrow));
            return;
        }

        if (pearl == null || !pearl.isAlive()) {
            if (pearlGoneTick < 0) {
                pearlGoneTick = now;
                diag.log("cycle", "pearl entity is gone at t=" + now);
            } else if (now - pearlGoneTick >= 3) {
                diag.verification("cycle", "pearl ended without a teleport signal (charge missed or pearl hit something else)");
                finish(mc, "no teleport");
            }
        }
    }

    /** Logs how far the real pearl is from where the physics model predicted it one tick ago. */
    private void logPearlAccuracy() {
        if (pearl == null || !pearl.isAlive()) {
            return;
        }
        Vec3d actual = new Vec3d(pearl.getX(), pearl.getY(), pearl.getZ());
        if (predictedPearlNext != null && config.diagnostics) {
            double err = actual.distanceTo(predictedPearlNext);
            if (err > 0.02) {
                diag.log("cycle", String.format("pearl model error %.3f (actual=(%.2f, %.2f, %.2f), predicted=(%.2f, %.2f, %.2f))",
                        err, actual.x, actual.y, actual.z, predictedPearlNext.x, predictedPearlNext.y, predictedPearlNext.z));
            }
        }
        predictedPearlNext = actual.add(pearl.getVelocity());
    }
}
