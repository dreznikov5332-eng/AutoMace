package com.automace.cycle;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import com.automace.inventory.InventoryManager;
import com.automace.inventory.ItemRole;
import com.automace.physics.InterceptSolver;
import com.automace.physics.InterceptSolver.Solution;
import com.automace.target.TargetManager;
import com.automace.tracker.PlayerStateTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.WindChargeEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Optional;
import java.util.Set;

/**
 * One ascent cycle: throw an ender pearl, then throw a wind charge so that it hits the pearl in flight;
 * the pearl then teleports the player to the point where it was hit.
 *
 * The cycle is driven by what the client sees (the pearl entity, the position jump of the player),
 * not by fixed timings. Every step is logged with tick numbers so that the physics defaults in the config
 * (drag, gravity, charge speed, latency) can be checked and corrected from a real run.
 *
 * Not done here (later stages): how many cycles and what height, and the spear lunge after the ascent.
 */
public final class PearlChargeCycle {

    private enum State { IDLE, AWAIT_PEARL, SOLVING, AWAIT_RESULT }

    private final AutoMaceConfig config;
    private final Diagnostics diag;
    private final InventoryManager inventory;
    private final TargetManager targets;
    private final PlayerStateTracker tracker;

    private State state = State.IDLE;
    private long startTick;
    private long pearlThrowTick;
    private long chargeThrowTick;

    private int originalSlot;
    private double yBeforeThrow;
    private Vec3d positionBeforeThrow;

    private final Set<Entity> ignoredPearls = Collections.newSetFromMap(new IdentityHashMap<>());
    private final Set<Entity> ignoredCharges = Collections.newSetFromMap(new IdentityHashMap<>());
    private Entity pearl;
    private Entity charge;
    private Vec3d predictedPearlNext;
    private Solution solution;
    private boolean chargeLogged;
    private long pearlGoneTick = -1;
    private boolean acquiredTarget;

    public PearlChargeCycle(AutoMaceConfig config, Diagnostics diag, InventoryManager inventory,
                            TargetManager targets, PlayerStateTracker tracker) {
        this.config = config;
        this.diag = diag;
        this.inventory = inventory;
        this.targets = targets;
        this.tracker = tracker;
    }

    public boolean isRunning() {
        return state != State.IDLE;
    }

    // ------------------------------------------------------------------ control

    public void start(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null || mc.interactionManager == null) {
            return;
        }
        if (state != State.IDLE) {
            diag.refusal("cycle", "already running (" + state + ")");
            return;
        }
        if (mc.currentScreen != null) {
            diag.refusal("cycle", "a screen is open");
            return;
        }
        int pearlSlot = inventory.findHotbarSlot(me, ItemRole.ENDER_PEARL);
        int chargeSlot = inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE);
        if (pearlSlot < 0 || chargeSlot < 0) {
            diag.refusal("cycle", "need an ender pearl and a wind charge in the hotbar");
            return;
        }

        // target is optional: it only sets the horizontal direction of the pearl throw
        PlayerEntity target = null;
        acquiredTarget = false;
        if (config.pearlThrowTowardsTarget) {
            if (targets.hasTarget()) {
                target = targets.current();
            } else if (targets.acquire(mc) == null) {
                target = targets.current();
                acquiredTarget = true;
            }
        }

        startTick = diag.tick();
        originalSlot = me.getInventory().getSelectedSlot();
        yBeforeThrow = me.getY();
        positionBeforeThrow = new Vec3d(me.getX(), me.getY(), me.getZ());
        pearl = null;
        charge = null;
        solution = null;
        chargeLogged = false;
        pearlGoneTick = -1;
        predictedPearlNext = null;

        ignoredPearls.clear();
        ignoredCharges.clear();
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof EnderPearlEntity) {
                ignoredPearls.add(e);
            } else if (e instanceof WindChargeEntity) {
                ignoredCharges.add(e);
            }
        }

        float yaw = me.getYaw();
        if (target != null) {
            double dx = target.getX() - me.getX();
            double dz = target.getZ() - me.getZ();
            yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        }
        useItemAimed(mc, me, pearlSlot, yaw, (float) config.pearlThrowPitch);
        pearlThrowTick = diag.tick();
        diag.action("cycle", String.format("pearl thrown: yaw=%.1f pitch=%.1f, player y=%.2f vy=%.3f",
                yaw, config.pearlThrowPitch, me.getY(), me.getVelocity().y));
        state = State.AWAIT_PEARL;
    }

    public void cancel(String reason) {
        if (state == State.IDLE) {
            return;
        }
        diag.log("cycle", "cancelled: " + reason);
        finish(MinecraftClient.getInstance(), "cancelled");
    }

    private void finish(MinecraftClient mc, String why) {
        if (mc != null && mc.player != null && originalSlot >= 0) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        diag.action("cycle", "finished: " + why + " (" + (diag.tick() - startTick) + " ticks)");
        if (acquiredTarget) {
            targets.release();
            acquiredTarget = false;
        }
        state = State.IDLE;
        pearl = null;
        charge = null;
        solution = null;
    }

    // ------------------------------------------------------------------ tick (end of client tick)

    public void tick(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (state == State.IDLE) {
            return;
        }
        if (me == null || mc.world == null) {
            state = State.IDLE;
            return;
        }
        if (me.isDead() || me.getHealth() <= 0f) {
            finish(mc, "player died");
            return;
        }
        long now = diag.tick();
        if (now - startTick > config.cycleTimeoutTicks) {
            finish(mc, "timeout");
            return;
        }

        scanEntities(mc, me);

        switch (state) {
            case AWAIT_PEARL -> {
                if (pearl != null) {
                    state = State.SOLVING;
                    solveAndThrow(mc, me);
                } else if (now - pearlThrowTick > 10) {
                    finish(mc, "no pearl entity appeared near the player");
                }
            }
            case SOLVING -> {
                logPearlAccuracy();
                if (pearl == null || !pearl.isAlive()) {
                    finish(mc, "pearl is gone before the charge was thrown");
                    return;
                }
                solveAndThrow(mc, me);
            }
            case AWAIT_RESULT -> awaitResult(mc, me, now);
            default -> { }
        }
    }

    /** Finds the pearl / charge that belong to this cycle: new entities close to the player's eye. */
    private void scanEntities(MinecraftClient mc, ClientPlayerEntity me) {
        Vec3d eye = me.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (pearl == null && e instanceof EnderPearlEntity && !ignoredPearls.contains(e)
                    && eye.distanceTo(new Vec3d(e.getX(), e.getY(), e.getZ())) < 4.0) {
                pearl = e;
                ignoredPearls.add(e);
                Vec3d v = e.getVelocity();
                diag.log("cycle", String.format("pearl entity seen at t=%d (+%d): pos=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) speed=%.3f",
                        diag.tick(), diag.tick() - pearlThrowTick, e.getX(), e.getY(), e.getZ(), v.x, v.y, v.z, v.length()));
            }
            if (state == State.AWAIT_RESULT && charge == null && e instanceof WindChargeEntity
                    && !ignoredCharges.contains(e)
                    && eye.distanceTo(new Vec3d(e.getX(), e.getY(), e.getZ())) < 4.0) {
                charge = e;
                ignoredCharges.add(e);
            }
        }
    }

    private void solveAndThrow(MinecraftClient mc, ClientPlayerEntity me) {
        Vec3d pos = new Vec3d(pearl.getX(), pearl.getY(), pearl.getZ());
        Vec3d vel = pearl.getVelocity();
        predictedPearlNext = pos.add(vel);

        int latency = config.interceptLatencyTicks;
        if (latency < 0) {
            latency = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(me.getNameForScoreboard());
                if (entry != null) {
                    latency = (int) Math.max(0, Math.min(10, Math.round(entry.getLatency() / 50.0)));
                }
            }
        }

        double radius = (config.pearlHitboxWidth + config.windChargeHitboxWidth) / 2.0 + config.interceptHitMargin;
        InterceptSolver.Params prm = new InterceptSolver.Params(config.pearlDrag, config.pearlGravity,
                config.windChargeSpeed, config.windChargeGravity, config.windChargeInheritsMomentum,
                radius, latency, config.interceptMaxTicksAhead, config.cycleMinHeightGain);

        Optional<Solution> sol = InterceptSolver.solve(pos, vel, me.getEyePos(), me.getVelocity(), me.getY(), prm);
        if (sol.isEmpty()) {
            diag.log("cycle", String.format("no intercept yet: pearl=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) latency=%d",
                    pos.x, pos.y, pos.z, vel.x, vel.y, vel.z, latency));
            return;
        }

        solution = sol.get();
        Vec3d d = solution.aimDirection();
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.asin(Math.max(-1.0, Math.min(1.0, d.y))));
        int chargeSlot = inventory.findHotbarSlot(me, ItemRole.WIND_CHARGE);
        if (chargeSlot < 0) {
            finish(mc, "wind charge disappeared from the hotbar");
            return;
        }
        useItemAimed(mc, me, chargeSlot, yaw, pitch);
        chargeThrowTick = diag.tick();
        diag.action("cycle", String.format(
                "charge thrown at t=%d: yaw=%.1f pitch=%.1f | solution: flight=%d ticks, impact=(%.2f, %.2f, %.2f), miss=%.3f, gain=%.2f, latency=%d | pearl was at (%.2f, %.2f, %.2f)",
                chargeThrowTick, yaw, pitch, solution.flightTicks(), solution.impactPoint().x,
                solution.impactPoint().y, solution.impactPoint().z, solution.missDistance(),
                solution.heightGain(), solution.latencyTicks(), pos.x, pos.y, pos.z));
        state = State.AWAIT_RESULT;
    }

    private void awaitResult(MinecraftClient mc, ClientPlayerEntity me, long now) {
        logPearlAccuracy();

        if (charge != null && !chargeLogged) {
            chargeLogged = true;
            Vec3d v = charge.getVelocity();
            diag.log("cycle", String.format("charge entity seen at t=%d (+%d): pos=(%.2f, %.2f, %.2f) vel=(%.3f, %.3f, %.3f) speed=%.3f (config speed %.3f)",
                    now, now - chargeThrowTick, charge.getX(), charge.getY(), charge.getZ(),
                    v.x, v.y, v.z, v.length(), config.windChargeSpeed));
        }

        if (tracker.lastTeleportSuspectedTick() >= chargeThrowTick) {
            Vec3d now3 = new Vec3d(me.getX(), me.getY(), me.getZ());
            diag.verification("cycle", String.format(
                    "TELEPORT detected at t=%d (+%d after the charge throw): new pos=(%.2f, %.2f, %.2f), height gain=%.2f, predicted impact=(%.2f, %.2f, %.2f)",
                    tracker.lastTeleportSuspectedTick(), tracker.lastTeleportSuspectedTick() - chargeThrowTick,
                    now3.x, now3.y, now3.z, now3.y - yBeforeThrow,
                    solution.impactPoint().x, solution.impactPoint().y, solution.impactPoint().z));
            finish(mc, "teleported, height gain " + String.format("%.2f", now3.y - yBeforeThrow));
            return;
        }

        if (pearl == null || !pearl.isAlive()) {
            if (pearlGoneTick < 0) {
                pearlGoneTick = now;
                diag.log("cycle", "pearl entity is gone at t=" + now);
            } else if (now - pearlGoneTick >= 3) {
                diag.verification("cycle", "pearl ended without a teleport signal (charge missed or pearl hit something else)");
                finish(mc, "no teleport");
            }
        }
    }

    /** Logs how far the real pearl is from where the physics model predicted it one tick ago. */
    private void logPearlAccuracy() {
        if (pearl == null || !pearl.isAlive()) {
            return;
        }
        Vec3d actual = new Vec3d(pearl.getX(), pearl.getY(), pearl.getZ());
        if (predictedPearlNext != null && config.diagnostics) {
            double err = actual.distanceTo(predictedPearlNext);
            if (err > 0.02) {
                diag.log("cycle", String.format("pearl model error %.3f (actual=(%.2f, %.2f, %.2f), predicted=(%.2f, %.2f, %.2f))",
                        err, actual.x, actual.y, actual.z, predictedPearlNext.x, predictedPearlNext.y, predictedPearlNext.z));
            }
        }
        Vec3d v = pearl.getVelocity();
        predictedPearlNext = actual.add(v);
    }

    // ------------------------------------------------------------------ helpers

    /**
     * Selects the slot, aims, uses the item and puts the camera back. The use packet carries the yaw/pitch
     * that were set at the moment of the call.
     */
    private void useItemAimed(MinecraftClient mc, ClientPlayerEntity me, int slot, float yaw, float pitch) {
        float oldYaw = me.getYaw();
        float oldPitch = me.getPitch();
        me.getInventory().setSelectedSlot(slot);
        me.setYaw(yaw);
        me.setPitch(pitch);
        mc.interactionManager.interactItem(me, Hand.MAIN_HAND);
        me.setYaw(oldYaw);
        me.setPitch(oldPitch);
    }
}
