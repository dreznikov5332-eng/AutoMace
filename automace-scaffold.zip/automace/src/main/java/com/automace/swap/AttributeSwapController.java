package com.automace.swap;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import com.automace.inventory.InventoryManager;
import com.automace.inventory.ItemRole;
import com.automace.tracker.PlayerStateTracker;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.List;

/**
 * Attribute Swap: switching the hotbar slot and attacking in the SAME game tick.
 *
 * Established from sources (see README, "Attribute Swap"):
 *  - the server applies item attributes once per tick; an attack that arrives in the same tick as the slot
 *    change is evaluated with the attributes (e.g. attack speed) of the item held BEFORE the switch, while the
 *    enchantment effects of the NEW item (e.g. Lunge) still apply;
 *  - this is the vanilla bug MC-28289; Mojang removed it in 26.2-pre-2, so it is not guaranteed on newer versions.
 *
 * Terms: carrier = item in hand BEFORE the swap (its attributes are used); effect item = item switched to.
 *
 * Confirmed by the user for the spear loop: carrier = wind charge, effect item = spear, the lunge is triggered by LMB,
 * and the sequence "carrier -> spear + LMB -> carrier" is done inside one tick so that there is no delay between lunges.
 *
 * Tick layout (one client tick):
 *   START_CLIENT_TICK -> startTick(): validates, selects the effect item, (ATTACK_KEY) registers an attack-key press
 *   vanilla input handling             -> processes that press with the effect item in hand
 *   END_CLIENT_TICK   -> endTick(): restores the carrier, records the result
 */
public final class AttributeSwapController {

    /** Action sent together with the slot change. */
    public enum SwapAction {
        /** Plain attack on a given target (attackEntity). Needs a target. */
        ATTACK_ENTITY,
        /** The real attack key (LMB): vanilla decides what the click does (jab, lunge ...). No target needed. */
        ATTACK_KEY
    }

    public record SwapPlan(String label, ItemRole carrierRole, ItemRole effectRole,
                           SwapAction action, boolean restoreCarrier) {
    }

    public enum Outcome { SENT, HIT_SIGNAL, NO_HIT_SIGNAL, ATTACK_SIGNAL, NO_ATTACK_SIGNAL }

    /** NOT_READY: normal waiting condition (e.g. attack charge). INVALID: something is wrong with the setup. */
    public enum RefusalKind { NOT_READY, INVALID }

    public record SwapResult(SwapPlan plan, long requestTick, long executeTick, int carrierSlot, int effectSlot,
                             boolean sameTick, float attackChargeBefore, Outcome outcome, String detail) {
    }

    public interface Listener {
        /** The slot change and the attack were sent in the same tick. */
        void onSwapSent(SwapResult result);

        /** Result is known (signal or no signal). Still not proof that the server accepted it. */
        void onSwapVerified(SwapResult result);

        void onSwapRefused(SwapPlan plan, String reason, RefusalKind kind);
    }

    private enum Phase { IDLE, PENDING, IN_FLIGHT, VERIFYING }

    private final AutoMaceConfig config;
    private final Diagnostics diag;
    private final InventoryManager inventory;
    private final PlayerStateTracker tracker;
    private final List<Listener> listeners = new ArrayList<>();

    private Phase phase = Phase.IDLE;
    private SwapPlan plan;
    private LivingEntity target;
    private long requestTick;

    private int carrierSlot;
    private int effectSlot;
    private float chargeBefore;
    private long switchTick;
    private SwapResult sent;
    private float targetHealthBefore;
    private long verifyDeadlineTick;

    public AttributeSwapController(AutoMaceConfig config, Diagnostics diag,
                                   InventoryManager inventory, PlayerStateTracker tracker) {
        this.config = config;
        this.diag = diag;
        this.inventory = inventory;
        this.tracker = tracker;
    }

    public void addListener(Listener l) {
        listeners.add(l);
    }

    public boolean isBusy() {
        return phase != Phase.IDLE;
    }

    /** Drops any pending swap. If the effect item is still selected, put the carrier back first. */
    public void cancel(String reason) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (phase == Phase.IN_FLIGHT && plan != null && plan.restoreCarrier()
                && mc.player != null && mc.getNetworkHandler() != null) {
            mc.player.getInventory().setSelectedSlot(carrierSlot);
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(carrierSlot));
        }
        if (phase != Phase.IDLE) {
            diag.log("swap", "cancelled: " + reason);
        }
        reset();
    }

    private void reset() {
        phase = Phase.IDLE;
        plan = null;
        target = null;
        sent = null;
    }

    /**
     * Queues a swap. It runs in startTick() of the next client tick. The target is only needed for ATTACK_ENTITY.
     */
    public boolean request(SwapPlan p, LivingEntity t) {
        if (phase != Phase.IDLE) {
            diag.refusal("swap", "swap already in progress (" + phase + ")");
            return false;
        }
        plan = p;
        target = t;
        requestTick = diag.tick();
        phase = Phase.PENDING;
        diag.action("swap", "requested '" + p.label() + "' carrier=" + p.carrierRole()
                + " effect=" + p.effectRole() + " action=" + p.action());
        return true;
    }

    // ------------------------------------------------------------------ START of the tick

    public void startTick(MinecraftClient mc) {
        if (phase != Phase.PENDING) {
            return;
        }
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) {
            cancel("no player/world");
            return;
        }
        if (!prepare(mc, me)) {
            return;
        }

        long now = diag.tick();
        switchTick = now;
        selectWithPacket(mc, me, effectSlot);
        diag.log("swap", "slot " + carrierSlot + " -> " + effectSlot + " (effect item selected, packet sent)");

        switch (plan.action()) {
            case ATTACK_ENTITY -> {
                targetHealthBefore = target.getHealth();
                mc.interactionManager.attackEntity(me, target);
                me.swingHand(Hand.MAIN_HAND);
                diag.log("swap", "attackEntity sent");
                if (plan.restoreCarrier()) {
                    selectWithPacket(mc, me, carrierSlot);
                    diag.log("swap", "slot " + effectSlot + " -> " + carrierSlot + " (carrier restored)");
                }
                sent = new SwapResult(plan, requestTick, now, carrierSlot, effectSlot, true, chargeBefore,
                        Outcome.SENT, "request->send delay " + (now - requestTick) + " tick(s)");
                diag.action("swap", "SENT " + sent.detail() + String.format(", charge before=%.2f", chargeBefore));
                phase = Phase.VERIFYING;
                verifyDeadlineTick = now + Math.max(1, config.swapVerifyWindowTicks);
                for (Listener l : listeners) {
                    l.onSwapSent(sent);
                }
            }
            case ATTACK_KEY -> {
                // Register an attack-key press. Vanilla input handling runs later in this same tick and
                // performs the click with the effect item in hand.
                KeyBinding attack = mc.options.attackKey;
                KeyBinding.onKeyPressed(KeyBindingHelper.getBoundKeyOf(attack));
                diag.log("swap", "attack key press registered");
                phase = Phase.IN_FLIGHT;
            }
        }
    }

    private boolean prepare(MinecraftClient mc, ClientPlayerEntity me) {
        if (plan.action() == SwapAction.ATTACK_ENTITY && (target == null || !target.isAlive())) {
            return refuse("target is gone", RefusalKind.INVALID);
        }
        if (mc.currentScreen != null) {
            return refuse("a screen is open", RefusalKind.INVALID);
        }

        carrierSlot = inventory.findHotbarSlot(me, plan.carrierRole());
        effectSlot = inventory.findHotbarSlot(me, plan.effectRole());
        if (carrierSlot < 0 || effectSlot < 0) {
            return refuse("missing item: carrier=" + plan.carrierRole() + "(" + carrierSlot + ") effect="
                    + plan.effectRole() + "(" + effectSlot + ")", RefusalKind.INVALID);
        }
        if (carrierSlot == effectSlot) {
            return refuse("carrier and effect item are in the same slot", RefusalKind.INVALID);
        }

        // The carrier has to be in hand already: the server applies its attributes once per tick.
        int held = me.getInventory().getSelectedSlot();
        if (held != carrierSlot) {
            return refuse("carrier is not in hand (held slot " + held + ", carrier slot " + carrierSlot + ")",
                    RefusalKind.INVALID);
        }
        long heldTicks = tracker.ticksSinceSlotChange();
        if (heldTicks < config.swapMinCarrierHeldTicks) {
            return refuse("carrier held for " + heldTicks + " tick(s), need " + config.swapMinCarrierHeldTicks,
                    RefusalKind.NOT_READY);
        }

        chargeBefore = me.getAttackCooldownProgress(0.5f);
        if (config.swapRequireFullAttackCharge && chargeBefore < 1.0f) {
            return refuse(String.format("attack charge %.2f < 1.00", chargeBefore), RefusalKind.NOT_READY);
        }
        return true;
    }

    private boolean refuse(String reason, RefusalKind kind) {
        SwapPlan p = plan;
        if (kind == RefusalKind.INVALID) {
            diag.refusal("swap", reason);
        } else {
            diag.log("swap", "waiting: " + reason);
        }
        reset();
        if (p != null) {
            for (Listener l : listeners) {
                l.onSwapRefused(p, reason, kind);
            }
        }
        return false;
    }

    private void selectWithPacket(MinecraftClient mc, ClientPlayerEntity me, int slot) {
        me.getInventory().setSelectedSlot(slot);
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    // ------------------------------------------------------------------ END of the tick

    public void endTick(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null || mc.getNetworkHandler() == null) {
            if (phase != Phase.IDLE) {
                reset();
            }
            return;
        }
        switch (phase) {
            case IN_FLIGHT -> finishKeyAttack(mc, me);
            case VERIFYING -> verifyEntityAttack();
            default -> { }
        }
    }

    private void finishKeyAttack(MinecraftClient mc, ClientPlayerEntity me) {
        long now = diag.tick();
        if (plan.restoreCarrier()) {
            selectWithPacket(mc, me, carrierSlot);
            diag.log("swap", "slot " + effectSlot + " -> " + carrierSlot + " (carrier restored)");
        }
        // Heuristic: a registered attack resets the attack charge.
        float chargeNow = me.getAttackCooldownProgress(0.5f);
        boolean signal = chargeNow < chargeBefore - 0.05f;
        boolean sameTick = switchTick == now;

        SwapResult result = new SwapResult(plan, requestTick, switchTick, carrierSlot, effectSlot, sameTick,
                chargeBefore, signal ? Outcome.ATTACK_SIGNAL : Outcome.NO_ATTACK_SIGNAL,
                String.format("request->send delay %d tick(s), same tick=%b, charge %.2f -> %.2f",
                        switchTick - requestTick, sameTick, chargeBefore, chargeNow));
        diag.action("swap", "SENT " + result.detail());
        diag.verification("swap", (signal ? "attack signal: " : "no attack signal: ") + result.detail());

        reset();
        for (Listener l : listeners) {
            l.onSwapSent(result);
        }
        for (Listener l : listeners) {
            l.onSwapVerified(result);
        }
    }

    /** Looks for a hit signal on the client. A heuristic: the server never says "hit". */
    private void verifyEntityAttack() {
        if (target == null || sent == null) {
            reset();
            return;
        }
        long now = diag.tick();
        boolean hurt = target.hurtTime > 0;
        boolean healthDropped = target.getHealth() < targetHealthBefore;

        if (hurt || healthDropped || now >= verifyDeadlineTick) {
            boolean signal = hurt || healthDropped;
            String detail = String.format("hurtTime=%d, health %.1f -> %.1f, %d tick(s) after the attack",
                    target.hurtTime, targetHealthBefore, target.getHealth(), now - sent.executeTick());
            SwapResult done = new SwapResult(sent.plan(), sent.requestTick(), sent.executeTick(),
                    sent.carrierSlot(), sent.effectSlot(), sent.sameTick(), sent.attackChargeBefore(),
                    signal ? Outcome.HIT_SIGNAL : Outcome.NO_HIT_SIGNAL, detail);
            diag.verification("swap", (signal ? "hit signal: " : "no hit signal: ") + detail);
            reset();
            for (Listener l : listeners) {
                l.onSwapVerified(done);
            }
        }
    }
}
