package com.automace.swap;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import com.automace.inventory.ItemRole;
import com.automace.swap.AttributeSwapController.RefusalKind;
import com.automace.swap.AttributeSwapController.SwapAction;
import com.automace.swap.AttributeSwapController.SwapPlan;
import com.automace.swap.AttributeSwapController.SwapResult;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

/**
 * Repeated spear lunges while a key is held: wind charge in hand -> (same tick) spear + LMB -> wind charge.
 * Standalone test mode for the Attribute Swap, independent of the combo state machine.
 * Pace is set by the game (attack charge, hunger), not by a fixed delay: a swap is requested every tick
 * and AttributeSwapController refuses it while the attack charge is not full.
 */
public final class LungeLoopController implements AttributeSwapController.Listener {
    private static final String LABEL = "lunge-loop";
    private static final SwapPlan PLAN = new SwapPlan(LABEL, ItemRole.WIND_CHARGE, ItemRole.SPEAR,
            SwapAction.ATTACK_KEY, true);

    private final AutoMaceConfig config;
    private final Diagnostics diag;
    private final AttributeSwapController swap;
    private final KeyBinding key;

    private boolean forced;
    private boolean running;
    private boolean suspended;
    private int lunges;
    private int invalidInRow;
    private long lastSentTick = -1_000_000L;

    public LungeLoopController(AutoMaceConfig config, Diagnostics diag,
                               AttributeSwapController swap, KeyBinding key) {
        this.config = config;
        this.diag = diag;
        this.swap = swap;
        this.key = key;
        swap.addListener(this);
    }

    /** The combo drives the loop without the key. */
    public void setForced(boolean on) {
        forced = on;
        if (on) {
            suspended = false;
        }
    }

    public boolean isRunning() {
        return running;
    }

    /** Call at the end of the tick, after AttributeSwapController.endTick(). */
    public void endTick(MinecraftClient mc) {
        if (!(key.isPressed() || forced) || !config.lungeLoopEnabled || mc.player == null) {
            if (running) {
                stop(!config.lungeLoopEnabled ? "disabled" : "key released");
            }
            suspended = false;
            return;
        }
        logImpulse(mc);
        if (suspended) {
            return;
        }
        if (!running) {
            running = true;
            lunges = 0;
            invalidInRow = 0;
            lastSentTick = -1_000_000L;
            diag.action("lunge", "loop started");
        }
        if (config.lungeLoopMaxLunges > 0 && lunges >= config.lungeLoopMaxLunges) {
            suspended = true;
            stop("max lunges reached (" + lunges + ")");
            return;
        }
        // configurable pause between lunges: wait until more than N ticks passed since the last one
        if (diag.tick() - lastSentTick <= (forced ? config.comboLungeDelayTicks : config.lungeLoopDelayTicks)) {
            return;
        }
        if (!swap.isBusy()) {
            swap.request(PLAN, null);
        }
    }

    /** For 5 ticks after every swap-lunge: the player's displacement and food level, to measure the real impulse. */
    private void logImpulse(MinecraftClient mc) {
        long since = diag.tick() - lastSentTick;
        if (since < 0 || since > 5 || lastSentTick < 0) {
            return;
        }
        net.minecraft.client.network.ClientPlayerEntity me = mc.player;
        net.minecraft.util.math.Vec3d v = me.getVelocity();
        diag.log("lunge", String.format("impulse +%d: velocity=(%.3f, %.3f, %.3f) horizontal=%.3f food=%d sat=%.1f sprint=%b ground=%b",
                since, v.x, v.y, v.z, Math.sqrt(v.x * v.x + v.z * v.z), me.getHungerManager().getFoodLevel(),
                me.getHungerManager().getSaturationLevel(), me.isSprinting(), me.isOnGround()));
    }

    /** Stop everything at once (emergency stop, disconnect). */
    public void emergencyStop(String reason) {
        if (running) {
            suspended = true;
            stop(reason);
        }
    }

    private void stop(String reason) {
        running = false;
        diag.action("lunge", "loop stopped: " + reason + " (" + lunges + " swap-attacks sent)");
    }

    @Override
    public void onSwapSent(SwapResult result) {
        if (LABEL.equals(result.plan().label())) {
            lunges++;
            invalidInRow = 0;
            lastSentTick = diag.tick();
        }
    }

    @Override
    public void onSwapVerified(SwapResult result) {
    }

    @Override
    public void onSwapRefused(SwapPlan plan, String reason, RefusalKind kind) {
        if (!LABEL.equals(plan.label()) || !running) {
            return;
        }
        if (kind == RefusalKind.INVALID && ++invalidInRow >= config.lungeLoopMaxInvalidRefusals) {
            suspended = true;
            stop("too many refusals in a row, last: " + reason);
        }
    }
}
