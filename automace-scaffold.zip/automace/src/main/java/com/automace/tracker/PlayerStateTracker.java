package com.automace.tracker;

import com.automace.config.AutoMaceConfig;
import com.automace.diagnostics.Diagnostics;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Per-tick snapshot of the local player. Separates "command sent" from "state actually changed":
 * everything here is read from the client world, never from what we asked for.
 */
public final class PlayerStateTracker {

    public record Snapshot(long tick, Vec3d pos, Vec3d velocity, float yaw, float pitch,
                           boolean onGround, boolean touchingWater, int selectedSlot, float attackCharge) {
        public double verticalSpeed() {
            return velocity.y;
        }

        public double horizontalSpeed() {
            return Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
        }
    }

    private final AutoMaceConfig config;
    private final Diagnostics diag;

    private Snapshot current;
    private Snapshot previous;

    private long lastSlotChangeTick = -1;
    private long lastTeleportSuspectedTick = -1;
    private double lastJumpDistance;

    private boolean maneuverActive;
    private double maneuverBaseY;
    private double maneuverMaxY;

    public PlayerStateTracker(AutoMaceConfig config, Diagnostics diag) {
        this.config = config;
        this.diag = diag;
    }

    public void update(ClientPlayerEntity p, long tick) {
        Snapshot next = new Snapshot(
                tick,
                new Vec3d(p.getX(), p.getY(), p.getZ()),
                p.getVelocity(),
                p.getYaw(),
                p.getPitch(),
                p.isOnGround(),
                p.isTouchingWater(),
                p.getInventory().getSelectedSlot(),
                p.getAttackCooldownProgress(0.5f));

        previous = current;
        current = next;

        if (previous != null) {
            if (previous.selectedSlot() != next.selectedSlot()) {
                lastSlotChangeTick = tick;
            }
            lastJumpDistance = next.pos().distanceTo(previous.pos());
            if (lastJumpDistance > config.teleportJumpThreshold) {
                lastTeleportSuspectedTick = tick;
                diag.log("tracker", String.format("position jump %.2f blocks (suspected teleport)", lastJumpDistance));
            }
        } else {
            lastSlotChangeTick = tick;
        }

        if (maneuverActive) {
            maneuverMaxY = Math.max(maneuverMaxY, next.pos().y);
        }
    }

    public void reset() {
        current = null;
        previous = null;
        maneuverActive = false;
        lastSlotChangeTick = -1;
        lastTeleportSuspectedTick = -1;
    }

    public Snapshot current() {
        return current;
    }

    public Snapshot previous() {
        return previous;
    }

    /** How many ticks the currently selected slot has been the same. */
    public long ticksSinceSlotChange() {
        return current == null || lastSlotChangeTick < 0 ? 0 : current.tick() - lastSlotChangeTick;
    }

    public boolean teleportSuspectedAt(long tick) {
        return lastTeleportSuspectedTick == tick;
    }

    public long lastTeleportSuspectedTick() {
        return lastTeleportSuspectedTick;
    }

    public double lastJumpDistance() {
        return lastJumpDistance;
    }

    // --- height of the current maneuver ---

    public void startManeuver() {
        if (current == null) {
            return;
        }
        maneuverActive = true;
        maneuverBaseY = current.pos().y;
        maneuverMaxY = maneuverBaseY;
    }

    public void endManeuver() {
        maneuverActive = false;
    }

    public double heightGained() {
        return maneuverActive ? maneuverMaxY - maneuverBaseY : 0.0;
    }

    public double maxHeightOfManeuver() {
        return maneuverMaxY;
    }
}
