package com.automace.config;

/**
 * Combo variants. Only the base variant is planned for now; the other variants from the spec
 * (DTap, Elytra DTap, Stun Slam, ...) are intentionally not listed until their sequences are confirmed.
 */
public enum ComboVariant {
    SPEAR_MACING
}
