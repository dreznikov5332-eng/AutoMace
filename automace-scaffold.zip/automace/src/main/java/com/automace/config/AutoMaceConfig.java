package com.automace.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Settings, stored as JSON in config/automace.json.
 * Intentionally holds NO pearl / wind charge timings: those are not fixed until the mechanics are confirmed.
 */
public final class AutoMaceConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("automace");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // --- general ---
    public boolean enabled = true;
    public ComboVariant variant = ComboVariant.SPEAR_MACING;

    // --- targeting ---
    /** true: nearest player; false: player under the crosshair. */
    public boolean autoTarget = true;
    public double maxTargetDistance = 64.0;
    public boolean requireLineOfSight = false;

    // --- inventory: hotbar slot 0..8, -1 = auto ---
    public int preferredSlotEnderPearl = -1;
    public int preferredSlotWindCharge = -1;
    public int preferredSlotSpear = -1;
    public int preferredSlotMace = -1;

    // --- combo ---
    /** Upper bound for ascent cycles. The real number is meant to be decided from the situation (stage 3). */
    public int maxAscentCycles = 6;
    /** Safety net against hanging, not a replacement for event checks. */
    public int defaultStateTimeoutTicks = 200;
    /** Minimum gap between two attempts (limits retry rate). */
    public int minTicksBetweenAttempts = 40;
    /** Player position jump (blocks) between two ticks treated as a suspected teleport. A threshold, not a timing. */
    public double teleportJumpThreshold = 3.0;

    // --- Attribute Swap ---
    /** Return to the carrier item in the same tick after the attack. */
    public boolean swapRestoreCarrier = true;
    /** Refuse the swap-attack when the attack charge is below 100% (value is logged either way). */
    public boolean swapRequireFullAttackCharge = true;
    /** The carrier must be held for at least this many ticks (the server applies attributes once per tick). */
    public int swapMinCarrierHeldTicks = 1;
    /** How many ticks after the attack to look for a hit signal on the target. */
    public int swapVerifyWindowTicks = 5;

    // --- lunge loop (hold the lunge key: wind charge -> spear + LMB -> wind charge, one tick per lunge) ---
    public boolean lungeLoopEnabled = true;
    /** 0 = unlimited while the key is held. */
    public int lungeLoopMaxLunges = 0;
    /** The loop pauses (until the key is released) after this many INVALID refusals in a row. */
    public int lungeLoopMaxInvalidRefusals = 3;

    // --- diagnostics ---
    public boolean diagnostics = true;
    public boolean showStateInActionBar = true;
    public int diagnosticsBufferSize = 200;

    public static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("automace.json");
    }

    public static AutoMaceConfig load() {
        Path p = path();
        if (Files.exists(p)) {
            try {
                AutoMaceConfig cfg = GSON.fromJson(Files.readString(p), AutoMaceConfig.class);
                if (cfg != null) {
                    cfg.save(); // writes newly added fields back
                    return cfg;
                }
            } catch (Exception e) {
                LOGGER.warn("[AutoMace] could not read config, using defaults: {}", e.toString());
            }
        }
        AutoMaceConfig cfg = new AutoMaceConfig();
        cfg.save();
        return cfg;
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException e) {
            LOGGER.warn("[AutoMace] could not save config: {}", e.toString());
        }
    }
}
