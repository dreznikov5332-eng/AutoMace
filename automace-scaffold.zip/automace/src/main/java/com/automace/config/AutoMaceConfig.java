package com.automace.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Settings, stored as JSON in config/automace.json.
 * Intentionally holds NO pearl / wind charge timings: those are not fixed until the mechanics are confirmed.
 */
public final class AutoMaceConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("automace");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // --- general ---
    public boolean enabled = true;
    public ComboVariant variant = ComboVariant.SPEAR_MACING;

    // --- targeting ---
    /** true: nearest player; false: player under the crosshair. */
    public boolean autoTarget = true;
    public double maxTargetDistance = 64.0;
    public boolean requireLineOfSight = false;
    /** TEST ONLY: also treat the Warden as a target (set to false in normal use). */
    public boolean targetWarden = true;

    // --- inventory: hotbar slot 0..8, -1 = auto ---
    public int preferredSlotEnderPearl = -1;
    public int preferredSlotWindCharge = -1;
    public int preferredSlotSpear = -1;
    public int preferredSlotMace = -1;

    // --- combo ---
    /** Upper bound for ascent cycles. The real number is meant to be decided from the situation (stage 3). */
    public int ascentCyclesMax = 2;
    /** After the smash start the next combo by itself until R is pressed again. */
    public boolean comboLoop = true;
    /** Wind Burst level on the mace: 0 (none) .. 3. */
    public int maceWindBurstLevel = 3;
    /** Approximate launch height of the smash per level. Source: Minecraft wiki mirror (about 8 / 16 / 24 blocks), NOT measured here: the mod logs the measured value after each smash. */
    public double windBurstHeightLevel1 = 8.0;
    public double windBurstHeightLevel2 = 16.0;
    public double windBurstHeightLevel3 = 24.0;
    public int comboBurstWaitTicks = 50;
    public int comboLoopPauseTicks = 20;
    /** Safety net against hanging, not a replacement for event checks. */
    public int defaultStateTimeoutTicks = 200;
    /** Minimum gap between two attempts (limits retry rate). */
    public int minTicksBetweenAttempts = 40;
    /** Player position jump (blocks) between two ticks treated as a suspected teleport. A threshold, not a timing. */
    public double teleportJumpThreshold = 3.0;

    // --- Attribute Swap ---
    /** Return to the carrier item in the same tick after the attack. */
    public boolean swapRestoreCarrier = true;
    /** Refuse the swap-attack when the attack charge is below 100% (value is logged either way). */
    public boolean swapRequireFullAttackCharge = true;
    /** The carrier must be held for at least this many ticks (the server applies attributes once per tick). */
    public int swapMinCarrierHeldTicks = 1;
    /** How many ticks after the attack to look for a hit signal on the target. */
    public int swapVerifyWindowTicks = 5;

    // --- lunge loop (hold the lunge key: wind charge -> spear + LMB -> wind charge, one tick per lunge) ---
    public boolean lungeLoopEnabled = true;
    /**
     * Idle ticks between two swap-lunges (20 ticks = 1 second). 0 = a lunge as often as the game allows.
     * Raise it if the spear gives only part of the boost (the game's lunge stacking, see README).
     */
    public int lungeLoopDelayTicks = 1;
    /** 0 = unlimited while the key is held. */
    public int lungeLoopMaxLunges = 0;
    /** The loop pauses (until the key is released) after this many INVALID refusals in a row. */
    public int lungeLoopMaxInvalidRefusals = 3;

    // --- pearl + wind charge cycle (stage 3). ALL values below are UNVERIFIED defaults: check them against the log ---
    // The pearl is thrown exactly where the crosshair looks. The charge direction and the moment of its throw are computed.
    public double pearlDrag = 0.99;
    public double pearlGravity = 0.03;
    public double windChargeSpeed = 1.5;
    public double windChargeGravity = 0.0;
    public boolean windChargeInheritsMomentum = true;
    /** Player vertical motion model while airborne (vanilla values, unverified). */
    public double playerGravity = 0.08;
    public double playerVerticalDrag = 0.98;
    /** Added on top of the hitbox radii of pearl and charge. */
    public double interceptHitMargin = 0.0;
    public double pearlHitboxWidth = 0.25;
    public double windChargeHitboxWidth = 0.3125;
    /** -1 = from ping (round trip / 50 ms), otherwise a fixed number of ticks. */
    public int interceptLatencyTicks = -1;
    /** How long the planner may wait before throwing the charge (more time = pearl flies higher / farther). */
    public int cycleMaxDelayTicks = 8;
    /** Max flight time of the charge considered by the planner. */
    public int cycleMaxFlightTicks = 14;
    /** The impact point must be at least this high above the player's feet (no teleport into the ground). */
    public double cycleMinImpactAboveFeet = 0.5;
    /** Score of a plan = heightWeight * height gain + distanceWeight * horizontal distance of the impact point. */
    public double cycleHeightWeight = 1.0;
    public double cycleDistanceWeight = 0.0;
    /** Minimum score for a plan to be used (with the default weights: minimum height gain in blocks). */
    public double cycleMinScore = 2.0;
    /** true: wait while the pearl / wind charge item cooldown is active; false: refuse to start. */
    /**
     * Measured from manual hits: the pearl was activated only while it still flew fast (speed >= ~0.8 blocks/tick,
     * early in the flight); passes near the apex / on the descent did nothing. Plans hitting a slower pearl are dropped.
     */
    public double cyclePearlMinVyAtHit = 0.6;
    /** Extra pearl vertical speed required while CHOOSING the pitch (borderline plans failed in real runs). */
    public double cyclePitchSearchVyMargin = 0.15;
    /** Score penalty per block of planned miss: prefers a dead-centre hit over a slightly higher but marginal one. */
    public double cycleMissPenalty = 8.0;
    /** Wind charge item cooldown in ticks (vanilla 10, unverified): the planner never plans a throw inside it. */
    public int windChargeCooldownTicks = 10;
    /**
     * Self boost: from the ground a wind charge is thrown straight down at the feet first; the pearl is thrown while the
     * player is rising and inherits the upward speed, so it flies higher.
     */
    public boolean cycleSelfBoostEnabled = true;
    /** Ticks between the boost charge and the pearl throw. */
    public int cycleBoostMaxWaitTicks = 14;
    public double cycleBoostPearlMaxVy = 0.15;
    public boolean cycleWaitForCooldown = true;
    public int cycleTimeoutTicks = 120;

    // --- full combo (ALL values are UNVERIFIED assumptions, tune them from the log) ---
    /** Pearl pitch during the ascent (negative = up). Yaw points at the target. */
    public float comboPearlPitch = -75f;
    /** Required height above the target: max(minHeightAboveTarget, horizontalDistance * heightPerBlock). */
    public double comboMinHeightAboveTarget = 10.0;
    public double comboHeightPerBlock = 0.5;
    /** Failed ascent cycles (no teleport) in a row before the combo gives up. */
    public int comboMaxCycleFailures = 2;
    /** How many times the combo may go back to ascending when the enemy moved / height ran out. */
    public int comboMaxReascents = 2;
    /** Re-ascend when during the dash the player is lower than this above the target (and still far). */
    public double comboMinHeightDuringDash = 2.0;
    /** Stop lunging below this distance to the target, then hold the spear and aim (momentum carries on). */
    public double comboLungeStopDistance = 4.5;
    /** Strike zone: the mace swap + attack happens at this distance or closer. */
    public double comboMaceDistance = 3.0;
    /** The dash only starts when the horizontal distance to the target is at most this (the lunge adds little speed). */
    public double comboMaxDashHorizontal = 6.0;
    /** The spear is selected and the swap requested this many ticks before the target is predicted to be in reach. */
    public double comboMaceLeadTicks = 3.0;
    /** Assumed horizontal speed gained by the lunges in the air (blocks/tick, measured ~0.1-0.15). */
    public double comboLungeSpeedPerTick = 0.5;
    /** Re-ascend because of a lack of distance only while at least this high above the target. */
    public double comboReascentMinHeight = 8.0;
    /** Idle ticks between lunges inside the combo (the V key keeps lungeLoopDelayTicks). */
    public int comboLungeDelayTicks = 0;
    /** Max ticks of the dash phase. */
    public int comboDashTimeoutTicks = 100;
    /** Max ticks trying the mace swap. */
    public int comboMaceTimeoutTicks = 40;

    // --- flight recorder: logs every pearl / wind charge (client + server) while one exists; passive ---
    public boolean flightRecorder = true;

    // --- diagnostics ---
    public boolean diagnostics = true;
    public boolean showStateInActionBar = true;
    public int diagnosticsBufferSize = 200;

    public static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("automace.json");
    }

    public static AutoMaceConfig load() {
        Path p = path();
        if (Files.exists(p)) {
            try {
                AutoMaceConfig cfg = GSON.fromJson(Files.readString(p), AutoMaceConfig.class);
                if (cfg != null) {
                    cfg.save(); // writes newly added fields back
                    return cfg;
                }
            } catch (Exception e) {
                LOGGER.warn("[AutoMace] could not read config, using defaults: {}", e.toString());
            }
        }
        AutoMaceConfig cfg = new AutoMaceConfig();
        cfg.save();
        return cfg;
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException e) {
            LOGGER.warn("[AutoMace] could not save config: {}", e.toString());
        }
    }
}
