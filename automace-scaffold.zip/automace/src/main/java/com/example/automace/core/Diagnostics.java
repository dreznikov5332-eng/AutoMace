package com.example.automace.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.function.Consumer;

/**
 * Журнал и «последние значения» для диагностического режима (раздел 12 ТЗ).
 * Не зависит от Minecraft: вывод в лог/экран подключается через sink.
 */
public final class Diagnostics {

    public record Entry(long tick, String category, String message) {
        @Override
        public String toString() {
            return "[" + tick + "] " + category + ": " + message;
        }
    }

    private final Deque<Entry> entries = new ArrayDeque<>();
    private final int capacity;
    private final Consumer<String> sink;

    private long tick;
    private boolean verbose;
    private String lastAction = "-";
    private String lastRefusal = "-";
    private String lastCheck = "-";

    public Diagnostics(int capacity, Consumer<String> sink) {
        this.capacity = Math.max(16, capacity);
        this.sink = sink == null ? s -> {} : sink;
    }

    public void setTick(long tick) {
        this.tick = tick;
    }

    public long tick() {
        return tick;
    }

    /** В подробном режиме каждая запись дублируется в sink (лог). Переходы и ошибки пишутся всегда. */
    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    public boolean verbose() {
        return verbose;
    }

    public void action(String message) {
        lastAction = message;
        add("action", message, false);
    }

    /** Причина, по которой следующее действие НЕ выполнено. */
    public void refusal(String message) {
        lastRefusal = message;
        add("refusal", message, false);
    }

    /** Результат проверки предыдущего этапа. */
    public void check(String message) {
        lastCheck = message;
        add("check", message, false);
    }

    public void transition(ComboState from, ComboState to, String reason) {
        add("state", from + " -> " + to + " (" + reason + ")", true);
    }

    public void error(String message) {
        add("error", message, true);
    }

    /** Записи о выполнении Attribute Swap: момент (тик) и результат. */
    public void swap(String message) {
        lastAction = message;
        add("swap", message, true);
    }

    private void add(String category, String message, boolean always) {
        Entry e = new Entry(tick, category, message);
        if (entries.size() >= capacity) entries.removeFirst();
        entries.addLast(e);
        if (always || verbose) sink.accept(e.toString());
    }

    public List<Entry> snapshot() {
        return new ArrayList<>(entries);
    }

    public String lastAction() {
        return lastAction;
    }

    public String lastRefusal() {
        return lastRefusal;
    }

    public String lastCheck() {
        return lastCheck;
    }

    public void clear() {
        entries.clear();
        lastAction = "-";
        lastRefusal = "-";
        lastCheck = "-";
    }
}
