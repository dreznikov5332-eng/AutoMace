package com.example.automace.core;

import java.util.EnumSet;
import java.util.Set;

/**
 * Состояния автомата (раздел 9 ТЗ). Для каждого: сторож-таймаут в тиках и допустимые переходы.
 *
 * Таймауты здесь - только защита от зависания (watchdog), а НЕ тайминги техники. Реальные условия
 * выхода из состояний (подтверждение телепорта, рост вертикальной скорости и т.д.) появятся на этапе 3.
 * Значения таймаутов - временные и подлежат уточнению после изучения демонстрации.
 *
 * Из любого состояния кроме IDLE всегда разрешён переход в RECOVERY (аварийный выход).
 */
public enum ComboState {
    IDLE(-1),
    TARGET_ACQUISITION(20),
    PREPARATION(20),
    PEARL_THROW(20),
    TELEPORT_CONFIRMATION(60),
    WIND_CHARGE(20),
    ASCENT_TRACKING(100),
    SPEAR_SETUP(40),
    SPEAR_ACTION(60),
    MACE_TRANSITION(10),
    MACE_ATTACK(200),
    RESULT_VERIFICATION(40),
    RECOVERY(20);

    private final int timeoutTicks;

    ComboState(int timeoutTicks) {
        this.timeoutTicks = timeoutTicks;
    }

    /** -1 = без таймаута. */
    public int timeoutTicks() {
        return timeoutTicks;
    }

    /** Штатные переходы для варианта Spear Macing (кроме аварийного перехода в RECOVERY). */
    public Set<ComboState> allowedNext() {
        return switch (this) {
            case IDLE -> EnumSet.of(TARGET_ACQUISITION);
            case TARGET_ACQUISITION -> EnumSet.of(PREPARATION);
            case PREPARATION -> EnumSet.of(PEARL_THROW, WIND_CHARGE, SPEAR_SETUP);
            case PEARL_THROW -> EnumSet.of(TELEPORT_CONFIRMATION);
            // После подтверждённого телепорта: ещё один цикл набора высоты или переход к заряду ветра.
            case TELEPORT_CONFIRMATION -> EnumSet.of(PEARL_THROW, WIND_CHARGE, ASCENT_TRACKING);
            case WIND_CHARGE -> EnumSet.of(ASCENT_TRACKING);
            // Перепланирование (цель резко сместилась): назад к набору высоты.
            case ASCENT_TRACKING -> EnumSet.of(PEARL_THROW, WIND_CHARGE, SPEAR_SETUP);
            case SPEAR_SETUP -> EnumSet.of(SPEAR_ACTION);
            case SPEAR_ACTION -> EnumSet.of(MACE_TRANSITION, PEARL_THROW, WIND_CHARGE);
            case MACE_TRANSITION -> EnumSet.of(MACE_ATTACK);
            case MACE_ATTACK -> EnumSet.of(RESULT_VERIFICATION, PEARL_THROW, WIND_CHARGE);
            case RESULT_VERIFICATION -> EnumSet.of(RECOVERY, TARGET_ACQUISITION);
            case RECOVERY -> EnumSet.of(IDLE);
        };
    }

    public boolean canGoTo(ComboState next) {
        if (this == IDLE) return next == TARGET_ACQUISITION;
        if (next == RECOVERY) return this != RECOVERY;
        return allowedNext().contains(next);
    }
}
