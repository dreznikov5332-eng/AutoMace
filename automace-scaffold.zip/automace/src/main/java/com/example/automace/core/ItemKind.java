package com.example.automace.core;

/** Типы предметов, которые нужны комбо. Сопоставление идёт по пути id предмета (без namespace). */
public enum ItemKind {
    ENDER_PEARL("Эндер-жемчуг", true),
    WIND_CHARGE("Заряд ветра", true),
    SPEAR("Копьё", false),
    MACE("Булава", false);

    private final String title;
    private final boolean consumable;

    ItemKind(String title, boolean consumable) {
        this.title = title;
        this.consumable = consumable;
    }

    public String title() {
        return title;
    }

    public boolean consumable() {
        return consumable;
    }

    /** @param itemPath путь id предмета, например "ender_pearl" или "netherite_spear". */
    public boolean matches(String itemPath) {
        if (itemPath == null) return false;
        return switch (this) {
            case ENDER_PEARL -> itemPath.equals("ender_pearl");
            case WIND_CHARGE -> itemPath.equals("wind_charge");
            case MACE -> itemPath.equals("mace");
            // Копья разных материалов: wooden_spear, iron_spear, netherite_spear и т.д.
            case SPEAR -> itemPath.endsWith("_spear");
        };
    }
}
