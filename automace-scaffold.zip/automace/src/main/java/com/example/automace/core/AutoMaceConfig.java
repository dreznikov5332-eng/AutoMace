package com.example.automace.core;

/**
 * Настройки (раздел 11 ТЗ). Простой POJO: сериализуется в JSON в ConfigStore.
 * Тайминги жемчуга/заряда ветра сюда НЕ входят - они ещё не определены.
 */
public final class AutoMaceConfig {

    /** Общий выключатель автоматического комбо. */
    public boolean enabled = true;

    /** Максимальная дистанция поиска цели, блоков. */
    public double maxTargetDistance = 48.0;

    /** true - ближайший игрок; false - игрок под прицелом. */
    public boolean autoTarget = true;

    /** Требовать прямую видимость цели при выборе. */
    public boolean requireLineOfSight = false;

    public ComboVariant variant = ComboVariant.SPEAR_MACING;

    public boolean usePearl = true;
    public boolean useWindCharge = true;

    /**
     * Предпочтительные слоты хотбара 0..8; -1 = искать автоматически.
     * Предметы между слотами инвентаря мод не перемещает.
     */
    public int slotPearl = -1;
    public int slotWindCharge = -1;
    public int slotSpear = -1;
    public int slotMace = -1;

    /** Использовать Attribute Swap при работе с копьём/булавой (модуль AttributeSwapController). */
    public boolean attributeSwap = true;

    /**
     * Минимальный уровень сытости для Lunge. Источники расходятся («не менее 6» и «больше 6»),
     * поэтому по умолчанию взято консервативное 7. Уточнить в игре.
     */
    public int minFoodForLunge = 7;

    /** Максимум повторных попыток комбо подряд (защита от бесконечных циклов). */
    public int maxRetries = 1;

    /** Подробный диагностический режим. */
    public boolean diagnostics = false;

    /** Приводит значения к допустимым диапазонам (на случай ручной правки файла). */
    public void validate() {
        if (variant == null) variant = ComboVariant.SPEAR_MACING;
        maxTargetDistance = Math.max(4.0, Math.min(128.0, maxTargetDistance));
        slotPearl = clampSlot(slotPearl);
        slotWindCharge = clampSlot(slotWindCharge);
        slotSpear = clampSlot(slotSpear);
        slotMace = clampSlot(slotMace);
        minFoodForLunge = Math.max(0, Math.min(20, minFoodForLunge));
        maxRetries = Math.max(0, Math.min(5, maxRetries));
    }

    private static int clampSlot(int slot) {
        return (slot < 0 || slot > 8) ? -1 : slot;
    }
}
