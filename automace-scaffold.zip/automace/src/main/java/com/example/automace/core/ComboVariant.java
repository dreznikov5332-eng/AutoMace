package com.example.automace.core;

/**
 * Варианты техники. Сейчас подтверждён к реализации только базовый Spear Macing.
 * Остальные (Spear DTap, Stun Slam и т.д.) намеренно НЕ добавлены: у каждого своя последовательность,
 * и реализовывать их по одному названию нельзя. Добавлять сюда новое значение + отдельный набор переходов.
 */
public enum ComboVariant {
    SPEAR_MACING("Spear Macing");

    private final String title;

    ComboVariant(String title) {
        this.title = title;
    }

    public String title() {
        return title;
    }
}
