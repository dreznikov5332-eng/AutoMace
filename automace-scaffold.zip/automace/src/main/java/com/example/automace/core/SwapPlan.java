package com.example.automace.core;

import java.util.List;

/**
 * План Attribute Swap: последовательность шагов, которая должна уложиться в ОДИН игровой тик.
 *
 * Что известно из открытых описаний (проверено по страницам модов/вики, не по исходникам игры):
 *  - сервер обновляет атрибуты предмета в руке один раз за тик; поэтому смена слота и атака в одном тике
 *    «смешивают» характеристики двух предметов;
 *  - Lunge swap: выбрать копьё -> ударить (jab) -> вернуть прежний слот, всё в одном тике;
 *  - Breach swap: ударить предметом A и сразу переключиться на булаву.
 *
 * Что НЕ установлено: какие именно атрибуты (скорость атаки / досягаемость / урон / чары) берутся от какого
 * предмета на связке «копьё -> булава» в 1.21.11 - это нужно подтвердить по демонстрации и тестам в игре.
 * Поэтому здесь описана только механика шагов, а конкретные планы для комбо задаст SpearController/MaceController
 * на этапе 4.
 */
public record SwapPlan(Kind kind, List<Step> steps) {

    public enum Kind {
        /** Выбрать копьё, ударить, вернуть слот - в одном тике. */
        LUNGE_SWAP,
        /** Ударить текущим предметом и сразу выбрать булаву. */
        MACE_SWAP
    }

    public enum StepType { SELECT_SLOT, ATTACK }

    public record Step(StepType type, int slot) {
        public static Step select(int slot) {
            return new Step(StepType.SELECT_SLOT, slot);
        }

        public static Step attack() {
            return new Step(StepType.ATTACK, -1);
        }
    }

    public SwapPlan {
        steps = List.copyOf(steps);
    }

    /** Lunge swap: [выбрать viaSlot, удар, выбрать returnSlot]. */
    public static SwapPlan selectAttackSelect(Kind kind, int viaSlot, int returnSlot) {
        return new SwapPlan(kind, List.of(Step.select(viaSlot), Step.attack(), Step.select(returnSlot)));
    }

    /** Breach swap: [удар текущим предметом, выбрать thenSlot]. */
    public static SwapPlan attackThenSelect(Kind kind, int thenSlot) {
        return new SwapPlan(kind, List.of(Step.attack(), Step.select(thenSlot)));
    }

    /** @return null, если план корректен, иначе описание проблемы. */
    public String validate() {
        int attacks = 0;
        for (Step s : steps) {
            if (s.type() == StepType.ATTACK) attacks++;
            if (s.type() == StepType.SELECT_SLOT && (s.slot() < 0 || s.slot() > 8)) {
                return "слот вне хотбара: " + s.slot();
            }
        }
        if (attacks != 1) return "в плане должен быть ровно один удар, найдено: " + attacks;
        if (steps.size() < 2) return "план слишком короткий";
        return null;
    }
}
