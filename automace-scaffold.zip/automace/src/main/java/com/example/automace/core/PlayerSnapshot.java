package com.example.automace.core;

/**
 * Неизменяемый снимок состояния игрока на конкретный тик (раздел 4 ТЗ).
 * Нужен, чтобы отличать «команда отправлена» от «состояние реально изменилось»: сравниваются снимки.
 */
public record PlayerSnapshot(
        long tick,
        double x, double y, double z,
        double vx, double vy, double vz,
        float yaw, float pitch,
        boolean onGround,
        int selectedSlot,
        int foodLevel,
        float health,
        double maxYSinceGround) {

    public double horizontalSpeed() {
        return Math.sqrt(vx * vx + vz * vz);
    }

    public double distanceTo(PlayerSnapshot other) {
        double dx = x - other.x, dy = y - other.y, dz = z - other.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Высота над точкой последнего касания земли (для клиента - наилучшая доступная оценка). */
    public double heightGainedSinceGround() {
        return maxYSinceGround - y >= 0 ? maxYSinceGround - y : 0;
    }

    /**
     * Признак телепортации между двумя снимками: сдвиг заметно больше того, что объясняется скоростью.
     * Порог задаётся вызывающим; конкретное значение будет подобрано на этапе 3 по реальным данным.
     */
    public boolean teleportedSince(PlayerSnapshot earlier, double thresholdBlocks) {
        return distanceTo(earlier) > thresholdBlocks;
    }
}
