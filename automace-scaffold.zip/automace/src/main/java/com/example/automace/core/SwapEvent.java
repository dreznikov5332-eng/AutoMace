package com.example.automace.core;

/**
 * Запись о выполненном Attribute Swap для диагностики (момент выполнения и переход к атаке).
 * sameTick() - ключевая проверка: все шаги плана должны быть выполнены в одном клиентском тике.
 */
public record SwapEvent(SwapPlan.Kind kind, long startTick, long endTick, int stepsDone, int stepsPlanned,
                        String note) {

    public boolean sameTick() {
        return startTick == endTick;
    }

    public boolean complete() {
        return stepsDone == stepsPlanned;
    }

    public boolean ok() {
        return complete() && sameTick();
    }

    @Override
    public String toString() {
        return kind + " тик " + startTick + (sameTick() ? "" : ".." + endTick)
                + ", шаги " + stepsDone + "/" + stepsPlanned
                + ", " + (ok() ? "OK (один тик)" : "НЕ В ОДИН ТИК / НЕ ПОЛНОСТЬЮ")
                + (note == null || note.isEmpty() ? "" : " [" + note + "]");
    }
}
