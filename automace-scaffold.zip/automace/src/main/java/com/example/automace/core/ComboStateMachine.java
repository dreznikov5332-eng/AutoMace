package com.example.automace.core;

/**
 * Конечный автомат комбо без привязки к Minecraft.
 * Проверяет допустимость переходов, считает тики в состоянии и срабатывает по таймауту (watchdog).
 */
public final class ComboStateMachine {

    private final Diagnostics diag;
    private ComboState state = ComboState.IDLE;
    private int ticksInState;
    private long enteredAtTick;
    private String lastReason = "-";

    public ComboStateMachine(Diagnostics diag) {
        this.diag = diag;
    }

    public ComboState state() {
        return state;
    }

    public boolean isIdle() {
        return state == ComboState.IDLE;
    }

    public int ticksInState() {
        return ticksInState;
    }

    public long enteredAtTick() {
        return enteredAtTick;
    }

    public String lastReason() {
        return lastReason;
    }

    /** @return true, если переход выполнен; false - если он недопустим (тогда состояние не меняется). */
    public boolean transition(ComboState next, String reason) {
        if (!state.canGoTo(next)) {
            diag.error("недопустимый переход " + state + " -> " + next + " (" + reason + ")");
            return false;
        }
        diag.transition(state, next, reason);
        state = next;
        ticksInState = 0;
        enteredAtTick = diag.tick();
        lastReason = reason;
        return true;
    }

    /** Аварийный выход. Из IDLE и повторно из RECOVERY ничего не делает. */
    public void abort(String reason) {
        if (state == ComboState.IDLE || state == ComboState.RECOVERY) return;
        diag.refusal(reason);
        transition(ComboState.RECOVERY, reason);
    }

    /** Вызывать один раз за тик. Увеличивает счётчик и проверяет сторож-таймаут. */
    public void tick() {
        if (state == ComboState.IDLE) return;
        ticksInState++;
        int limit = state.timeoutTicks();
        if (limit > 0 && ticksInState > limit) {
            if (state == ComboState.RECOVERY) {
                // RECOVERY сам завис - принудительно в IDLE, чтобы не застрять.
                diag.error("таймаут RECOVERY, принудительный сброс в IDLE");
                forceIdle("таймаут RECOVERY");
            } else {
                abort("таймаут состояния " + state + " (" + limit + " тиков)");
            }
        }
    }

    /** Завершение восстановления. */
    public void finishRecovery() {
        if (state == ComboState.RECOVERY) transition(ComboState.IDLE, "восстановление завершено");
    }

    public void forceIdle(String reason) {
        diag.transition(state, ComboState.IDLE, reason);
        state = ComboState.IDLE;
        ticksInState = 0;
        enteredAtTick = diag.tick();
        lastReason = reason;
    }
}
