package com.example.automace.core;

/** Геометрия наведения (углы в градусах, конвенция Minecraft: yaw 0 = +Z, pitch >0 = вниз). */
public final class Aim {
    private Aim() {}

    public static float yawTo(double dx, double dz) {
        return (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
    }

    public static float pitchTo(double dx, double dy, double dz) {
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        return (float) -Math.toDegrees(Math.atan2(dy, horizontal));
    }

    public static double horizontalDistance(double dx, double dz) {
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** Приводит угол к диапазону (-180; 180]. */
    public static float wrapDegrees(float angle) {
        float a = angle % 360.0f;
        if (a > 180.0f) a -= 360.0f;
        if (a <= -180.0f) a += 360.0f;
        return a;
    }
}
