# AutoMace (scaffold, stage 1-2)

Client-side Fabric mod for Minecraft Java **1.21.11**. This stage contains the framework only.
The combo itself (pearl / wind charge / spear / mace) is **not implemented**: its mechanics are not verified yet.

## Build

```
./gradlew build        # jar: build/libs/automace-0.1.0.jar
./gradlew runClient    # test client
```
Requires JDK 21. Versions (loader 0.20.1, Loom 1.19-SNAPSHOT, Fabric API 0.141.6+1.21.11) come from the official
`fabric-example-mod`, branch `1.21.11`. The Yarn build `1.21.11+build.6` in `gradle.properties` is taken from the last
tag of FabricMC/yarn branch 1.21.11 and has not been checked against maven. If Gradle cannot resolve it, copy the
Yarn number from https://fabricmc.net/develop.

**Status of verification:** the project has NOT been compiled (maven.fabricmc.net / libraries.minecraft.net are blocked
in the authoring sandbox). What was checked: Java syntax (javac parse), every `net.minecraft.*` import and the
class / method names used against the Yarn mappings of branch 1.21.11, Fabric API event names against the Fabric API
1.21.11 sources. The first `./gradlew build` on your machine is the real compile check.

## Keys and config
- `R` start combo, `X` emergency stop, `V` lunge loop (hold), `C` pearl + wind charge cycle, rebind in Controls, category "AutoMace".
- `config/automace.json` is created on first start (no GUI yet; a settings screen is a later step).

## Modules
| Module | State |
|---|---|
| `TargetManager` | done: nearest / crosshair target, lock, validity checks |
| `PlayerStateTracker` | done: position, velocity, ground, slot, attack charge, teleport-jump flag, maneuver height |
| `InventoryManager` | done: finds pearl / wind charge / spear / mace in the hotbar, counts consumables |
| `Diagnostics` | done: tick-stamped log, last action / refusal / verification, action bar line |
| `ComboController` | state machine with all 13 states; stops with a reason at PEARL_THROW (not implemented) |
| `AttributeSwapController` | primitive done, not wired into a combo (see below) |
| `LungeLoopController` | done (untested in game): hold `V` -> repeated wind charge -> spear + LMB -> wind charge, one tick per lunge |
| `PearlChargeCycle` + `InterceptSolver` | stage 3a, untested in game: throws a pearl, predicts its flight, throws a wind charge to hit it, detects the teleport; all physics values in the config are unverified defaults checked via the log |
| `SpearController`, `MaceController` | skeletons, `isDefined() == false` |

## Attribute Swap: what is known
Sources: Auto Lunge Swap and Auto-Attribute-Swap mod pages, Mojang bug MC-28289, feedback.minecraft.net thread on 26.2-pre-2.
- Attribute swap = change the hotbar slot and attack **in the same game tick**.
- The server applies item attributes once per tick, so the attack uses the attributes (e.g. attack speed) of the item held
  **before** the switch, while enchantment effects of the **new** item (e.g. Lunge) still apply.
- It is the vanilla bug MC-28289; Mojang removed it in 26.2-pre-2 (restored in pre-3). For 1.21.11 it is reported to work,
  but it is a bug, not a feature, and many servers treat it as cheating.

Confirmed by the user for the spear loop: carrier = wind charge, effect item = spear, the lunge is triggered by LMB, and
"wind charge -> spear + LMB -> wind charge" is done inside one tick, so there is no delay between lunges.

Implementation (`swap/AttributeSwapController`), one client tick:
1. `START_CLIENT_TICK` (before vanilla input handling): select the spear, send the slot packet, register an attack-key
   press (`KeyBinding.onKeyPressed`, action `ATTACK_KEY`).
2. Vanilla input handling performs the click with the spear in hand.
3. `END_CLIENT_TICK`: select the wind charge again, send the slot packet, record the result.
The tracker is updated after the restore, so it always sees the carrier as the held item.
`ATTACK_ENTITY` (attack on a given target) is also available. Refuses if the carrier is not in hand,
was selected less than `swapMinCarrierHeldTicks` ticks ago, or the attack charge is below 100% (configurable).
Diagnostics log tick numbers of request / slot change / attack / restore and a hit-signal check
(`hurtTime`, health drop) for `swapVerifyWindowTicks` ticks. The hit signal is a heuristic, the server never confirms a hit.

Interaction: `SpearController` / `MaceController` build a `SwapPlan`, `ComboController` passes it to
`AttributeSwapController.request()` and receives `onSwapSent / onSwapVerified / onSwapRefused`.

## Not confirmed (needs a demonstration or in-game test, nothing here is guessed)
1. Which carrier / effect item pair the Spear Mace technique needs, and in which phase the swap happens.
2. Whether the vanilla click really performs the lunge when processed this way, and whether it can repeat every tick
   (vanilla may have its own click cooldown). The loop logs `attack signal / no attack signal` per lunge (the attack
   charge resets after a registered attack) for exactly this check.
3. Whether the Lunge impulse is gated by attack charge, hunger, or being airborne (Auto Lunge Swap mentions food and charge).
4. Pearl / wind charge interaction and timing, spear dash direction and moment, mace switch moment.
5. Spears are recognised by item id suffix `_spear` (provisional).
6. `attackEntity` is assumed to send the attack after the slot packet, in this order, within the tick (we send the slot packet explicitly first).

## Stage 3a: pearl + wind charge cycle (key `C`)
Hotbar needs an ender pearl and a wind charge.
1. The pearl is thrown exactly where the crosshair looks (no aim change). If the pearl is on cooldown the cycle waits (`cycleWaitForCooldown`).
2. When the pearl entity is seen, the planner (`InterceptSolver`) runs every tick: for every possible throw delay (0..`interceptMaxDelayTicks`)
   and every aim it simulates charge and pearl (continuous collision of the two hitboxes) and picks the plan with the best score = `cycleHeightWeight` * height gain + `cycleDistanceWeight` * horizontal distance
   (defaults 1.0 / 0.0: the charge hits the pearl IN FLIGHT as high as possible, not just before landing; plans below `cycleMinScore` are dropped;
   plans within 0.25 block of the best prefer the earlier throw), impact at least `cycleMinImpactAboveFeet` above the feet.
   Looking upwards gives the pearl more time, so the planner waits longer before the charge is thrown.
   The player's own movement (running) is part of the model: the charge is thrown from where the player will be after the delay,
   it inherits the player's momentum (`windChargeInheritsMomentum`), and the aim compensates that momentum. The movement is taken from
   the real displacement over the last tick and re-planned every tick.
3. When the best plan has delay 0 (and the wind charge is off cooldown) the charge is thrown with the computed aim (camera is restored).
4. The teleport is detected as a position jump; everything is logged (category `cycle`).
Log lines to check the physics: `pearl model error`, `charge entity seen ... vel= | expected vel=`, `plan: throw the charge in N tick(s)`,
`charge thrown ...`, `TELEPORT detected ... height gain`.
Unverified defaults (config): pearl drag 0.99, gravity 0.03, charge speed 1.5, no charge gravity, charge inherits player momentum,
latency from ping. Ignored: terrain, random projectile spread, charge lifetime/range.
Not done: number of cycles / total height, the lunge after the ascent.
