# AutoMace (scaffold, stage 1-2)

Client-side Fabric mod for Minecraft Java **1.21.11**. This stage contains the framework only.
The combo itself (pearl / wind charge / spear / mace) is **not implemented**: its mechanics are not verified yet.

## Build

```
./gradlew build        # jar: build/libs/automace-0.1.0.jar
./gradlew runClient    # test client
```
Requires JDK 21. Versions (loader 0.20.1, Loom 1.19-SNAPSHOT, Fabric API 0.141.6+1.21.11) come from the official
`fabric-example-mod`, branch `1.21.11`. The Yarn build `1.21.11+build.6` in `gradle.properties` is taken from the last
tag of FabricMC/yarn branch 1.21.11 and has not been checked against maven. If Gradle cannot resolve it, copy the
Yarn number from https://fabricmc.net/develop.

**Status of verification:** the project has NOT been compiled (maven.fabricmc.net / libraries.minecraft.net are blocked
in the authoring sandbox). What was checked: Java syntax (javac parse), every `net.minecraft.*` import and the
class / method names used against the Yarn mappings of branch 1.21.11, Fabric API event names against the Fabric API
1.21.11 sources. The first `./gradlew build` on your machine is the real compile check.

## Keys and config
- `R` start combo, `X` emergency stop, `V` lunge loop (hold), `C` pearl + wind charge cycle, rebind in Controls, category "AutoMace".
- `config/automace.json` is created on first start (no GUI yet; a settings screen is a later step).

## Modules
| Module | State |
|---|---|
| `TargetManager` | done: nearest / crosshair target, lock, validity checks |
| `PlayerStateTracker` | done: position, velocity, ground, slot, attack charge, teleport-jump flag, maneuver height |
| `InventoryManager` | done: finds pearl / wind charge / spear / mace in the hotbar, counts consumables |
| `Diagnostics` | done: tick-stamped log, last action / refusal / verification, action bar line |
| `ComboController` | state machine with all 13 states; stops with a reason at PEARL_THROW (not implemented) |
| `AttributeSwapController` | primitive done, not wired into a combo (see below) |
| `LungeLoopController` | done (untested in game): hold `V` -> repeated wind charge -> spear + LMB -> wind charge, one tick per lunge |
| `PearlChargeCycle` + `InterceptSolver` | stage 3a, untested in game: throws a pearl, predicts its flight, throws a wind charge to hit it, detects the teleport; all physics values in the config are unverified defaults checked via the log |
| `SpearController`, `MaceController` | skeletons, `isDefined() == false` |

## Attribute Swap: what is known
Sources: Auto Lunge Swap and Auto-Attribute-Swap mod pages, Mojang bug MC-28289, feedback.minecraft.net thread on 26.2-pre-2.
- Attribute swap = change the hotbar slot and attack **in the same game tick**.
- The server applies item attributes once per tick, so the attack uses the attributes (e.g. attack speed) of the item held
  **before** the switch, while enchantment effects of the **new** item (e.g. Lunge) still apply.
- It is the vanilla bug MC-28289; Mojang removed it in 26.2-pre-2 (restored in pre-3). For 1.21.11 it is reported to work,
  but it is a bug, not a feature, and many servers treat it as cheating.

Confirmed by the user for the spear loop: carrier = wind charge, effect item = spear, the lunge is triggered by LMB, and
"wind charge -> spear + LMB -> wind charge" is done inside one tick, so there is no delay between lunges.

Implementation (`swap/AttributeSwapController`), one client tick:
1. `START_CLIENT_TICK` (before vanilla input handling): select the spear, send the slot packet, register an attack-key
   press (`KeyBinding.onKeyPressed`, action `ATTACK_KEY`).
2. Vanilla input handling performs the click with the spear in hand.
3. `END_CLIENT_TICK`: select the wind charge again, send the slot packet, record the result.
The tracker is updated after the restore, so it always sees the carrier as the held item.
`ATTACK_ENTITY` (attack on a given target) is also available. Refuses if the carrier is not in hand,
was selected less than `swapMinCarrierHeldTicks` ticks ago, or the attack charge is below 100% (configurable).
Diagnostics log tick numbers of request / slot change / attack / restore and a hit-signal check
(`hurtTime`, health drop) for `swapVerifyWindowTicks` ticks. The hit signal is a heuristic, the server never confirms a hit.

Interaction: `SpearController` / `MaceController` build a `SwapPlan`, `ComboController` passes it to
`AttributeSwapController.request()` and receives `onSwapSent / onSwapVerified / onSwapRefused`.

## Not confirmed (needs a demonstration or in-game test, nothing here is guessed)
1. Which carrier / effect item pair the Spear Mace technique needs, and in which phase the swap happens.
2. Whether the vanilla click really performs the lunge when processed this way, and whether it can repeat every tick
   (vanilla may have its own click cooldown). The loop logs `attack signal / no attack signal` per lunge (the attack
   charge resets after a registered attack) for exactly this check.
3. Whether the Lunge impulse is gated by attack charge, hunger, or being airborne (Auto Lunge Swap mentions food and charge).
4. Pearl / wind charge interaction and timing, spear dash direction and moment, mace switch moment.
5. Spears are recognised by item id suffix `_spear` (provisional).
6. `attackEntity` is assumed to send the attack after the slot packet, in this order, within the tick (we send the slot packet explicitly first).

## Stage 3a: pearl + wind charge cycle (key `C`)
Hotbar needs an ender pearl and a wind charge.
1. The pearl is thrown exactly where the crosshair looks (no aim change). If the pearl is on cooldown the cycle waits (`cycleWaitForCooldown`).
2. When the pearl entity is seen, the planner (`InterceptSolver`) runs every tick: for every possible throw delay (0..`interceptMaxDelayTicks`)
   and every aim it simulates charge and pearl (continuous collision of the two hitboxes) and picks the plan with the best score = `cycleHeightWeight` * height gain + `cycleDistanceWeight` * horizontal distance
   (defaults 1.0 / 0.0: the charge hits the pearl IN FLIGHT as high as possible, not just before landing; plans below `cycleMinScore` are dropped;
   plans within 0.25 block of the best prefer the earlier throw), impact at least `cycleMinImpactAboveFeet` above the feet.
   Looking upwards gives the pearl more time, so the planner waits longer before the charge is thrown.
   The player's own movement (running) is part of the model: the charge is thrown from where the player will be after the delay,
   it inherits the player's momentum (`windChargeInheritsMomentum`), and the aim compensates that momentum. The movement is taken from
   the real displacement over the last tick and re-planned every tick.
3. When the best plan has delay 0 (and the wind charge is off cooldown) the charge is thrown with the computed aim (camera is restored).
4. The teleport is detected as a position jump; everything is logged (category `cycle`).
Log lines to check the physics: `pearl model error`, `charge entity seen ... vel= | expected vel=`, `plan: throw the charge in N tick(s)`,
`charge thrown ...`, `TELEPORT detected ... height gain`.
Unverified defaults (config): pearl drag 0.99, gravity 0.03, charge speed 1.5, no charge gravity, charge inherits player momentum,
latency from ping. Ignored: terrain, random projectile spread, charge lifetime/range.
Not done: number of cycles / total height, the lunge after the ascent.

## Full combo (key R)
Target (nearest player) -> ascent cycles (pearl yaw at the target, pitch `comboPearlPitch`; planner as in stage 3a) repeated until
height above the target >= max(`comboMinHeightAboveTarget`, horizontal distance * `comboHeightPerBlock`), up to `maxAscentCycles`
-> spear dash (lunge loop, camera aimed at the target every tick) -> within `comboLungeStopDistance` the spear is selected and an
Attribute Swap attack with the mace follows (carrier spear, effect mace; the full-charge rule is relaxed for this step).
If the player lands or drops lower than `comboMinHeightDuringDash` above the target, the combo goes back to ascending
(`comboMaxReascents`). X stops everything. ALL combo constants are UNVERIFIED assumptions: Lunge III impulse, required height formula,
spear as the carrier for the mace swap. Calibrate from `config/automace-log.txt` (category `combo`, `cycle`, `trace`, `swap`).

## Log findings (first in-game test)
- Pearl: the velocity read from the entity is the one BEFORE the tick's drag/gravity; the real step is v*0.99 and v.y*0.99-0.03.
  The solver used v (error 0.035/tick); fixed.
- Charge spawns at the eye and moves 1.5/tick; its real velocity differs from the expected one by up to ~0.02/tick (projectile spread).
- Several cycles showed the client positions overlapping with no hit. Trace lines now also carry `SRV` (integrated server truth) to find out why.

## What the manual-hit log showed (recorder, singleplayer)
- Hit case: straight up, charge thrown 4 ticks after the pearl, the charge crosses the pearl at pearl age 16-18 (pearl speed ~0.8, y ~ +20),
  the pearl is removed 2 ticks later and the player is moved to it; the charge is NOT consumed (it keeps flying, its velocity changes).
- 13 of 13 crossings with a pearl speed >= 0.8 hit (lateral offsets up to 0.37 block); crossings with a slow / descending pearl
  (speed < 0.6) did not, even when central. The planner now drops such plans (`cyclePearlMinSpeedAtHit` = 0.75).
- Unexplained: one hit at pearl speed 0.27 (pearl age 31).

## Round 3 (log 52cd99fc)
- Most cycles now hit (+20 blocks). Misses were marginal plans (planned miss 0.22-0.28) plus projectile spread: planner now penalises the planned miss (`cycleMissPenalty`).
- Pearl pitch is chosen from the horizontal distance to the target (`suggestPitch`): the teleport point lands above the target; the dash only starts when the horizontal distance is <= `comboMaxDashHorizontal`.
- The lunge adds only ~0.1-0.15 blocks/tick in the air; if the fall time is not enough to cover the distance the combo throws the next pearl at once (stays in the air).
- The mace is prepared (spear selected) early: distance threshold = reach + closing speed * `comboMaceLeadTicks`; the swap is requested when the distance one tick ahead is within reach.

## Round 4
- Self boost (`cycleSelfBoost`): from the ground a wind charge is thrown straight down first, the pearl follows `cycleBoostWaitTicks` later and inherits the upward speed. The planner respects the wind charge item cooldown (`windChargeCooldownTicks`).
- After a combo ascent cycle the wind charge stays selected (no extra tick before the first lunge); lunges in the combo use `comboLungeDelayTicks` (0).
- Every lunge logs the player's velocity, food and sprint state for 5 ticks (`[lunge] impulse`) to measure the real impulse.

## Round 5: settings screen
- Key `0` opens an in-game settings screen (pages, [-]/[+] buttons, toggles). Values apply instantly and are saved to `config/automace.json`. Use it to tune `comboLungeDelayTicks` / `lungeLoopDelayTicks` / `swapRequireFullAttackCharge` without rebuilding.
- The preflight check and any combo failure reason are now also printed to the in-game chat.
- The action-bar status is toggled by `showStateInActionBar`.

## Round 6 (log 9dae942c)
- Self boost (wind charge at the feet) broke the pearl model: client pearl position lags the server one while the player moves up (server pearl ~2.3 b/tick, client pos ~0.6 b/tick), so charges missed and the pearl stayed in the air until timeout. Every cycle that started with the boost failed/timed out, every airborne cycle hit. FIX (instead of disabling): the cycle now propagates the pearl with its own physics model from the first seen state (pos + velocity are correct at first sight) and ignores the lagging client position. Boost stays ON (`cycleSelfBoostEnabled`). New log lines: `client pearl lag`, `sim velocity differs`.
- A timed-out cycle left its pearl flying; it later teleported the player and spoiled the next cycle. Combo now waits until the own pearl is gone before a new ascent cycle.
- Dash: the first lunge used the stale yaw from the last pearl throw (flew AWAY from the target, horizontal distance grew 2.2 -> 6.4). Now aimed at the target before the first lunge.
- Measured lunge: ~0.65-0.9 blocks/tick horizontal in the air (earlier 0.1-0.25 was wrong). `comboLungeSpeed` replaced by `comboLungeSpeedPerTick` = 0.5.

## Round 7 (log 1da0cc26)
- Pearl sim works (client lag ~0 in this log; slow drift of sim vs client y ~0.3 after 50 ticks, so constants are very slightly off: not important for short flights).
- Hits happened mostly when the flight was short; the planner chose 30-40 tick flights (charge spread grows with distance) and waited up to 48 ticks. New defaults: `cycleMaxDelayTicks=8`, `cycleMaxFlightTicks=14` (renamed, so old configs do not keep 30/40) -> many fast cycles.
- Settings screen: text colors had alpha 0 (invisible in 1.21.11); now 0xFF......, layout shifted so labels do not overlap the buttons.
